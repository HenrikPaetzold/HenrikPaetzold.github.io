
public class Epsilon extends EBNFNode {

	@Override
	public String toEBNFString() {
		return "";
	}
	
	@Override
	public String toString() {
		return "Epsilon()";
	}

}
