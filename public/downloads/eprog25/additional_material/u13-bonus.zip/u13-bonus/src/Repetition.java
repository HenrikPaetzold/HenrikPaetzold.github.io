
public class Repetition extends EBNFNode {
	
	private final EBNFNode child;
	
	public Repetition(EBNFNode child) {
		super();
		this.child = child;
	}

	@Override
	public String toEBNFString() {
		
		
		return "{"+child.toEBNFString()+"}";
	}

	@Override
	public String toString() {
		return "Repetition(" + child + ")";
	}
	
	public EBNFNode child() {
		return child;
	}
}
