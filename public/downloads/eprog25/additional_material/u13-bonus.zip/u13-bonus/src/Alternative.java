
public class Alternative extends EBNFNode {

	private final EBNFNode first, second;
	
	public Alternative(EBNFNode first, EBNFNode second) {
		super();
		this.first = first;
		this.second = second;
	}

	@Override
	public String toEBNFString() {
		// TODO task a
		
		return this.first.toEBNFString() + "|" + this.second.toEBNFString();
	}
	
	@Override
	public String toString() {
		return "Alternative(" + first + ", " + second + ")";
	}
	
	public EBNFNode first() {
		return first;
	}
	
	public EBNFNode second() {
		return second;
	}

}
