
public class Option extends EBNFNode {
	
	private final EBNFNode child;
	
	public Option(EBNFNode child) {
		super();
		this.child = child;
	}

	@Override
	public String toEBNFString() {
		return "["+child.toEBNFString()+"]";
	}
	
	@Override
	public String toString() {
		return "Option(" + child + ")";
	}
	
	public EBNFNode getChild() {
		return child;
	}
}
