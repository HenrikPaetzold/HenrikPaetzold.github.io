import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;

public class EBNFRules implements EBNFString {

	private final Map<String, EBNFNode> rules;
	LinkedList<String> sortedKeys;

	private final Map<String, Set<String>> memo = new HashMap<>();

	public EBNFRules(Map<String, EBNFNode> rules) {
		this.rules = rules;
		sortedKeys = new LinkedList<>(rules.keySet());
		Collections.sort(sortedKeys);
	}

	@Override
	public String toEBNFString() {
		String res = "";
		for (String key : sortedKeys) {
			EBNFNode temp = rules.get(key);
			res += "<" + key + "><-" + temp.toEBNFString() + "\n";
		}
		return res;
	}

	public Set<String> getShortestWords(String name, int limit) {
		if (!sortedKeys.contains(name))
			throw new IllegalEBNFDescriptionException();
		Set<String> allCombinations = simulateRule(rules.get(name), limit);
		Set<String> result = new HashSet<>();
		for (String word : allCombinations) {
			if (word.length() <= limit)
				result.add(word);
		}
		return result;
	}

	public Set<String> simulateRule(EBNFNode currNode, int limit) {
		String memoKey = currNode.toString() + ":limit=" + limit;

		if (memo.containsKey(memoKey)) {
			return memo.get(memoKey);
		}

		Set<String> res = new LinkedHashSet<>();

		if (currNode instanceof Literal || currNode instanceof Epsilon) {
			res.add(currNode.toEBNFString());
			memo.put(memoKey, res);
			return res;
		}

		if (currNode instanceof Alternative) {
			Alternative alt = (Alternative) currNode;
			Set<String> resA = simulateRule(alt.first(), limit);
			Set<String> resB = simulateRule(alt.second(), limit);
			res.addAll(resA);
			res.addAll(resB);

			memo.put(memoKey, res);
			return res;
		}

		if (currNode instanceof Option) {
			Option op = (Option) currNode;
			Set<String> withOption = simulateRule(op.getChild(), limit);

			res.add("");

			res.addAll(withOption);

			memo.put(memoKey, res);
			return res;
		}

		if (currNode instanceof Sequence) {
			Sequence seq = (Sequence) currNode;
			Set<String> resLeft = simulateRule(seq.left(), limit);
			Set<String> resRight = simulateRule(seq.right(), limit);

			for (String l : resLeft) {
				for (String r : resRight) {
					String conc = l + r;
					if (conc.length() <= limit) {
						res.add(conc);
					}
				}
			}

			memo.put(memoKey, res);
			return res;
		}


		if (currNode instanceof Repetition) {
			Repetition rep = (Repetition) currNode;

			Set<String> childExp = simulateRule(rep.child(), limit);

			Queue<String> queue = new LinkedList<>();
			queue.offer("");

			Set<String> visited = new HashSet<>();
			visited.add("");

			while (!queue.isEmpty()) {
				String current = queue.poll();
				res.add(current);

				for (String c : childExp) {
					String newStr = current + c;
					if (newStr.length() <= limit && !visited.contains(newStr)) {
						visited.add(newStr);
						queue.offer(newStr);
					}
				}
			}

			memo.put(memoKey, res);
			return res;
		}
		
		 if (currNode instanceof Brackets) {
		        Brackets br = (Brackets) currNode;
		        Set<String> childRes = simulateRule(br.getChild(), limit);
		        res.addAll(childRes);

		        memo.put(memoKey, res);
		        return res;
		        }

		if (currNode instanceof RuleName) {
			String name = ((RuleName) currNode).name();
			if (!sortedKeys.contains(name)) {
				throw new IllegalEBNFDescriptionException();
			}
			res = simulateRule(rules.get(name), limit);
			memo.put(memoKey, res);
			return res;
		}

		memo.put(memoKey, res);
		return res;
	}
}
