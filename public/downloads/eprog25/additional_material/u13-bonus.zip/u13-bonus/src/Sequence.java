
public class Sequence extends EBNFNode {
	
	private final EBNFNode left, right;
	
	public Sequence(EBNFNode left, EBNFNode right) {
		super();
		this.left = left;
		this.right = right;
	}

	@Override
	public String toEBNFString() {
		// TODO task a
		String left = this.left.toEBNFString();
		String right = this.right.toEBNFString();
		if(this.left instanceof Alternative)left = "("+this.left.toEBNFString()+")";
		if(this.right instanceof Alternative)right = "("+this.right.toEBNFString()+")";
		return left+right;
	}
	
	@Override
	public String toString() {
		return "Sequence(" + left + ", " + right + ")";
	}
	
	public EBNFNode right() {
		return right;
	}
	
	public EBNFNode left() {
		return left;
	}
}
