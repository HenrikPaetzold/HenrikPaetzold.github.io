
public class Labyrinth {

	public static boolean task1(Room room) {
		// TODO
		return false;
	}
	
	public static boolean task2(Room room) {
		// TODO
		return false;
	}
}
