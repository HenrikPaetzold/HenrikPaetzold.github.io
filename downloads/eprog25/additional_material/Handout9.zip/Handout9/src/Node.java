import java.util.LinkedList;

public class Node {
    private LinkedList<Node> children = new LinkedList<>();
    private int id;
    public Node(int identifier){
        this.id = identifier;
    }
    public LinkedList<Node> getChildren() {
        return children;
    }

    public void addChild(Node node){
        children.add(node);
    }

    public String toString(){
        return ""+id;
    }
}
