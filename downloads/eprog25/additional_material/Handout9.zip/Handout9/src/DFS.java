import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

public class DFS {

    public static void main(String[] args) {
        // Knoten anlegen
        Node n1 = new Node(1);
        Node n2 = new Node(2);
        Node n3 = new Node(3);
        Node n4 = new Node(4);
        Node n5 = new Node(5);
        Node n6 = new Node(6);
        Node n7 = new Node(7);
        Node n8 = new Node(8);
        Node n9 = new Node(9);
        Node n10 = new Node(10);
        Node n11 = new Node(11);
        Node n12 = new Node(12);

        // Hauptäste
        // 1 → 2,3,4
        n1.addChild(n2);
        n1.addChild(n3);
        n1.addChild(n4);

        // 2 → 5,6
        n2.addChild(n5);
        n2.addChild(n6);

        // 3 → 6,7
        n3.addChild(n6);
        n3.addChild(n7);

        // 4 → 7
        n4.addChild(n7);

        // 5 → 8
        n5.addChild(n8);

        // 6 → 8,9
        n6.addChild(n8);
        n6.addChild(n9);

        // 7 → 9,10
        n7.addChild(n9);
        n7.addChild(n10);

        // 8 → 11
        n8.addChild(n11);

        // 9 → 11
        n9.addChild(n11);

        // 10 → 12
        n10.addChild(n12);

        // Querverbindungen / Zyklen
        // 5 → 3 (Back-Edge), 10 → 6 (Cross-Edge), 12 → 3 (Back-Edge)
        n5.addChild(n3);
        n10.addChild(n6);
        n12.addChild(n3);

        System.out.println("Iteratives DFS:");
        dfsIterative(n1);

        System.out.println("\nRekursives DFS:");
        dfsRecursive(n1, new java.util.HashSet<>());
    }


    public static void dfsIterative(Node start) {
        Set<Node> visited = new HashSet<>();
        LinkedList<Node> stack = new LinkedList<>();
        stack.push(start);
        while(!stack.isEmpty()){
            Node curr = stack.pop();
            visited.add(curr);
            LinkedList<Node> children = curr.getChildren();
            for (int i = children.size() - 1; i >= 0; i--) { // Nicht notwendig. Gibt selbee Reihenfolge, wie rekursives DFS
                Node child = children.get(i);
                if(!visited.contains(child)){
                    stack.push(child);
                }
            }
            System.out.println(curr);
        }
    }

    public static void dfsRecursive(Node curr, Set<Node> visited){
        System.out.println(curr);
        visited.add(curr);
        for(Node child : curr.getChildren()){
            if(!visited.contains(child))dfsRecursive(child, visited);
        }
    }
}
