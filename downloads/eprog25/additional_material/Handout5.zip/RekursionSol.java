public class RecTasks {

    // ================================
    // Aufgabe 1: Summe eines Arrays
    // ================================
    /**
     * Berechnet die Summe aller Elemente eines Arrays rekursiv.
     * @param xs Das Eingabearray
     * @return Die Summe aller Werte im Array
     */
    public static int sum(int[] xs) {
        // Spezialfall: leeres Array → Summe ist 0
        return xs.length == 0 ? 0 : sumFrom(xs, 0);
    }

    /**
     * Hilfsmethode: summiert die Elemente ab Index i.
     * @param xs Das Eingabearray
     * @param i Aktueller Index
     * @return Summe der Elemente von xs[i] bis Ende
     */
    private static int sumFrom(int[] xs, int i) {
        // Abbruchbedingung: letztes Element erreicht
        if (i == xs.length - 1) return xs[i];
        // Rekursiver Fall: aktuelles Element + Summe der restlichen
        return xs[i] + sumFrom(xs, i + 1);
    }

    // ================================
    // Aufgabe 2: Zeichen zählen
    // ================================
    /**
     * Zählt, wie oft ein bestimmtes Zeichen in einem String vorkommt.
     * @param c Das zu suchende Zeichen
     * @param s Der Eingabestring
     * @return Anzahl der Vorkommen von c in s
     */
    public static int count(char c, String s) {
        // Abbruchbedingung: leerer String → keine Treffer
        if (s.isEmpty()) return 0;

        // Falls erstes Zeichen gleich c ist → +1, sonst +0
        int matches = s.charAt(0) == c ? 1 : 0;

        // Rekursion mit Rest des Strings (ohne das erste Zeichen)
        return matches + count(c, s.substring(1));
    }

    // ================================
    // Aufgabe 3: Prüfen, ob Array sortiert ist
    // ================================
    /**
     * Prüft, ob das Array aufsteigend sortiert ist.
     * @param xs Das Eingabearray
     * @return true, wenn sortiert oder leer, sonst false
     */
    public static boolean isSorted(int[] xs) {
        // Ein leeres Array gilt als sortiert
        return xs.length == 0 || sortedFrom(xs, 0);
    }

    /**
     * Hilfsmethode: prüft ab Index i, ob die restlichen Elemente sortiert sind.
     */
    private static boolean sortedFrom(int[] xs, int i) {
        // Abbruchbedingung: letztes Element erreicht → sortiert
        if (i == xs.length - 1) return true;

        // Rekursion nur, wenn aktuelle Reihenfolge korrekt ist
        return xs[i] <= xs[i + 1] && sortedFrom(xs, i + 1);
    }

    // ================================
    // Aufgabe 4: Doppelte Zeichenläufe entfernen
    // ================================
    /**
     * Entfernt aufeinanderfolgende gleiche Zeichen (z. B. "aabbcc" → "abc").
     * @param s Eingabestring
     * @return String ohne aufeinanderfolgende Duplikate
     */
    public static String dedupRuns(String s) {
        // Startet mit keinem "letzten" Zeichen
        return dedupFrom(s, '.', false);
    }

    /**
     * Hilfsmethode: entfernt Duplikate, kennt das letzte Zeichen.
     * @param s Rest des Strings
     * @param last Das zuletzt verarbeitete Zeichen
     * @param hasLast Gibt an, ob es bereits ein "letztes" Zeichen gibt
     */
    private static String dedupFrom(String s, char last, boolean hasLast) {
        // Abbruchbedingung: kein Rest mehr
        if (s.isEmpty()) return "";

        char current = s.charAt(0);

        // Wenn noch kein "letztes" Zeichen existiert, einfach übernehmen
        if (!hasLast)
            return current + dedupFrom(s.substring(1), current, true);

        // Wenn gleiches Zeichen wie zuvor → überspringen
        if (last == current)
            return dedupFrom(s.substring(1), current, true);

        // Sonst Zeichen übernehmen und weiter
        return current + dedupFrom(s.substring(1), current, true);
    }

    // ================================
    // Aufgabe 5: Geschweifte Klammern balanciert?
    // ================================
    /**
     * Prüft, ob geschweifte Klammern '{' und '}' im String balanciert sind.
     * Andere Zeichen werden ignoriert.
     * @param s Eingabestring
     * @return true, wenn alle Klammern korrekt geöffnet/geschlossen sind
     */
    static boolean isBalanced(String s) {
        return check(s, 0);
    }

    /**
     * Hilfsmethode: überprüft Balance, hält die Anzahl offener Klammern.
     * @param s Rest des Strings
     * @param open Anzahl aktuell geöffneter, noch nicht geschlossener Klammern
     * @return true, wenn korrekt balanciert, sonst false
     */
    static boolean check(String s, int open) {
        // Ungültig: mehr schließende als öffnende
        if (open < 0) return false;

        // Abbruchbedingung: keine Zeichen mehr → gültig, wenn open == 0
        if (s.isEmpty()) return open == 0;

        char c = s.charAt(0);

        // Öffnende Klammer → Zähler +1
        if (c == '{') return check(s.substring(1), open + 1);
        // Schließende Klammer → Zähler -1
        if (c == '}') return check(s.substring(1), open - 1);

        // Andere Zeichen ignorieren
        return check(s.substring(1), open);
    }
}
