import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RectangleTest {

    @Test
    public void testConstructorValidInput() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        assertEquals(5.0, rect.getWidth(), 0.01);
        assertEquals(10.0, rect.getHeight(), 0.01);
    }

    @Test
    public void testConstructorInvalidWidth() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Rectangle(0, 10.0);
        });
        assertEquals("Die Breite muss größer als null sein.", exception.getMessage());
    }

    @Test
    public void testConstructorInvalidHeight() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Rectangle(5.0, 0);
        });
        assertEquals("Die Höhe muss größer als null sein.", exception.getMessage());
    }

    @Test
    public void testGetWidth() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        assertEquals(5.0, rect.getWidth(), 0.01);
    }

    @Test
    public void testGetHeight() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        assertEquals(10.0, rect.getHeight(), 0.01);
    }

    @Test
    public void testSetWidthValid() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        rect.setWidth(8.0);
        assertEquals(8.0, rect.getWidth(), 0.01);
    }

    @Test
    public void testSetWidthInvalid() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            rect.setWidth(-1.0);
        });
        assertEquals("Die Breite muss größer als null sein.", exception.getMessage());
    }

    @Test
    public void testSetHeightValid() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        rect.setHeight(12.0);
        assertEquals(12.0, rect.getHeight(), 0.01);
    }

    @Test
    public void testSetHeightInvalid() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            rect.setHeight(-2.0);
        });
        assertEquals("Die Höhe muss größer als null sein.", exception.getMessage());
    }

    @Test
    public void testGetArea() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        assertEquals(50.0, rect.getArea(), 0.01);
    }

    @Test
    public void testGetPerimeter() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        assertEquals(30.0, rect.getPerimeter(), 0.01);
    }

    @Test
    public void testIsLargerThan() {
        Rectangle rect1 = new Rectangle(5.0, 10.0); // Fläche = 50.0
        Rectangle rect2 = new Rectangle(4.0, 10.0); // Fläche = 40.0
        Rectangle rect3 = new Rectangle(5.0, 10.0); // Fläche = 50.0

        assertTrue(rect1.isLargerThan(rect2)); // rect1 sollte größer sein
        assertFalse(rect1.isLargerThan(rect3)); // rect1 und rect3 sind gleich groß
    }

    @Test
    public void testToString() {
        Rectangle rect = new Rectangle(5.0, 10.0);
        assertEquals("Rectangle [width=5.0, height=10.0]", rect.toString());
    }
}
