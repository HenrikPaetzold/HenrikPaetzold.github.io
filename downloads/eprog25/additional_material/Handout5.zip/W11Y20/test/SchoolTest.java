import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SchoolTest {

    @Test
    void testProvidedExample() {
        School hogwarts = new School();

        House hufflepuff = hogwarts.createHouse("Hufflepuff");
        House ravenclaw  = hogwarts.createHouse("Ravenclaw");

        Student hannah = new Student("Hannah", "Abbott");
        Student newton = new Student("Newton", "Scamander");
        Student luna   = new Student("Luna", "Lovegood");
        Student filius = new Student("Filius", "Flitwick");

        hufflepuff.assign(hannah);
        hufflepuff.assign(newton);
        ravenclaw.assign(luna);
        ravenclaw.assign(filius);

        hannah.givePoints(10);
        newton.givePoints(-5);
        luna.givePoints(8);

        assertEquals("Ravenclaw", hogwarts.winner().name());
        assertEquals(8, hogwarts.winner().points());
        assertEquals(13, hogwarts.points());
    }

    @Test
    void testHouseNames() {
        School hogwarts = new School();

        // null name → IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> hogwarts.createHouse(null));

        hogwarts.createHouse("Hufflepuff");

        // duplicate name → IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> hogwarts.createHouse("Hufflepuff"));
    }

    @Test
    void testStudentCreation() {
        Student hannah = new Student("Hannah", "Abbott");
        assertEquals("Hannah", hannah.firstName());
        assertEquals("Abbott", hannah.lastName());
    }

    @Test
    void testHouseAssignments() {
        School hogwarts = new School();

        House hufflepuff = hogwarts.createHouse("Hufflepuff");
        House ravenclaw  = hogwarts.createHouse("Ravenclaw");

        Student hannah = new Student("Hannah", "Abbott");

        hufflepuff.assign(hannah);

        // cannot assign same student to a different house
        assertThrows(IllegalArgumentException.class, () -> ravenclaw.assign(hannah));

        // cannot assign same student twice to same house
        assertThrows(IllegalArgumentException.class, () -> hufflepuff.assign(hannah));

        // student can be assigned to another school
        School durmstrang = new School();
        House atticus = durmstrang.createHouse("Atticus");
        atticus.assign(hannah);
    }

    @Test
    void testZeroPointsWinner() {
        School hogwarts = new School();
        House ravenclaw  = hogwarts.createHouse("Ravenclaw");

        assertEquals("Ravenclaw", hogwarts.winner().name());
        assertEquals(0, ravenclaw.points());
    }

    @Test
    void testNegativeHousePoints() {
        School hogwarts = new School();
        House ravenclaw  = hogwarts.createHouse("Ravenclaw");

        Student luna   = new Student("Luna", "Lovegood");
        Student filius = new Student("Filius", "Flitwick");

        ravenclaw.assign(luna);
        ravenclaw.assign(filius);

        luna.givePoints(8);
        filius.givePoints(-10);

        assertEquals(0, ravenclaw.points());
    }
}
