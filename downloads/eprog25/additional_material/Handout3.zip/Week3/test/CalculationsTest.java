import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculationsTest {

    @Test
    void testChecksum_basicCases() {
        assertEquals(0, Calculations.checksum(0));
        assertEquals(5, Calculations.checksum(5));
        assertEquals(3, Calculations.checksum(12));
        assertEquals(13, Calculations.checksum(49));
        assertEquals(15, Calculations.checksum(258));
        assertEquals(11, Calculations.checksum(1091));
        assertEquals(36, Calculations.checksum(9999));
    }

    @Test
    void testChecksum_largeNumbers() {
        assertEquals(1, Calculations.checksum(1000));
        assertEquals(19, Calculations.checksum(1990));
        assertEquals(45, Calculations.checksum(123456789));
    }

    @Test
    void testChecksum_repeatedDigits() {
        assertEquals(18, Calculations.checksum(666));
        assertEquals(9, Calculations.checksum(333));
    }

    @Test
    void testMagic7_basic() {
        assertTrue(Calculations.magic7(7, 1));
        assertTrue(Calculations.magic7(1, 7));
        assertTrue(Calculations.magic7(2, 5));
        assertTrue(Calculations.magic7(9, 16));
        assertFalse(Calculations.magic7(5, 5));
    }

    @Test
    void testMagic7_withZeroAndNegatives() {
        assertTrue(Calculations.magic7(0, 7));
        assertTrue(Calculations.magic7(10, 3));
        assertTrue(Calculations.magic7(-7, 0));
        assertTrue(Calculations.magic7(-2, 9));
        assertTrue(Calculations.magic7(8, 1));
    }

    @Test
    void testMagic7_edgeCases() {
        assertTrue(Calculations.magic7(0, 7));
        assertTrue(Calculations.magic7(14, 7));
        assertFalse(Calculations.magic7(1, 1));
        assertFalse(Calculations.magic7(-3, -4));
    }

    @Test
    void testFast12_near12() {
        assertTrue(Calculations.fast12(12));
        assertTrue(Calculations.fast12(11));
        assertTrue(Calculations.fast12(13));
        assertTrue(Calculations.fast12(10));
        assertTrue(Calculations.fast12(14));
        assertFalse(Calculations.fast12(9));
        assertFalse(Calculations.fast12(15));
    }

    @Test
    void testFast12_multipleOf12() {
        assertTrue(Calculations.fast12(0));
        assertTrue(Calculations.fast12(24));
        assertTrue(Calculations.fast12(26));
        assertTrue(Calculations.fast12(22));
        assertFalse(Calculations.fast12(27));
    }

    @Test
    void testFast12_randomValues() {
        assertFalse(Calculations.fast12(5));
        assertFalse(Calculations.fast12(33));
        assertTrue(Calculations.fast12(36));
        assertTrue(Calculations.fast12(37));
        assertTrue(Calculations.fast12(34));
        assertFalse(Calculations.fast12(39));
    }
}
