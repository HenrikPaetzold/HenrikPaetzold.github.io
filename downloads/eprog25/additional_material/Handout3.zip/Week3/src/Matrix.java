public class Matrix {

    public static void main(String[] args){
        System.out.println("Tests in dem Test directory");
    }

    static boolean checkMatrix(int[][] m) {
        // Fuellen sie die Funktion, um die Aufgabe zu lösen
        return false;
    }
}
