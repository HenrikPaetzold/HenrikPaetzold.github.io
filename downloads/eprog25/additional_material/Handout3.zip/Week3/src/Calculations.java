public class Calculations {
    public static void main(String[] args){
        System.out.println("Tests in dem Test directory");
    }

    public static int checksum(int x){
        return -1;
    }

    public static boolean magic7(int a, int b){

        return false;
    }

    public static boolean fast12(int x) {
        return false;
    }
}
