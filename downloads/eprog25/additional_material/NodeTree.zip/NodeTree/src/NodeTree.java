import java.util.Arrays;
import java.util.Collections;

public class NodeTree {

    public static void main(String[] args) {

    }
    
    
    public static int calculateSum(Node origin) {
    	// TODO Aufgabe 2.1
    	return -1;

    }

    public static int highestPath(Node origin) {
    	// TODO Aufgabe 2.2
    	return -1;
    }

    public static int calculateTriSum(Node origin) {
    	// TODO Aufgabe 2.3
    	return -1;
    }
    
    public static Node[] highestTriPath(Node origin) {
    	// TODO Aufgabe 2.4
    	return null;
    }
    
}
