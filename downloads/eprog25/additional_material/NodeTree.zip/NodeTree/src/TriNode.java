public class TriNode extends Node {

	/***
	*   Sie duerfen diese Klasse nicht verändern!
	***/

	public Node third;
	
	public TriNode(int value) {
		super(value);
	}
	
	public TriNode(int value, Node first, Node second, Node third) {
		super(value, first, second);
		this.third = third;
	}
	
	public int getValue() {
		return super.getValue();
	}

}
