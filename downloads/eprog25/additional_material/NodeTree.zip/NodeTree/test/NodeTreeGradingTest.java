import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class NodeTreeGradingTest {
	public static Node buildExample(Node o1, Node o2) {
		// build tree from example
		Node seven = new Node(7, o2, null);
		Node mtwo = new Node(-2, null, seven);
		Node one = new Node(1);
		Node four = new Node(4, mtwo, one);
		Node mthree = new Node(-3, null, o1);
		Node two = new Node(2, mthree, four);
		return two;
	}
	
	public static Node buildSecond(Node o1, Node o2) {
		Node msix = new Node(-6, null, o2);
		Node mone = new Node(-1);
		Node three = new Node(3, mone, msix);
		Node two = new Node(2, o1, null);
		Node zero = new Node(0, two, null);
		Node mten = new Node(-10, null, zero);
		Node four = new Node(4, mten, null);
		Node five = new Node(5, four, three);
		return five;
	}
	
	@Test
	public void testCalculateSum1() {
		// Aufgabe 2.1
		Node origin = buildExample(null, null);
		int res = NodeTree.calculateSum(origin);
		assertEquals(9, res);
	}
	
	@Test
	public void testCalculateSum2() {
		// Aufgabe 2.1
		Node origin = buildSecond(null, null);
		int res = NodeTree.calculateSum(origin);
		assertEquals(-3, res);
	}
	
	@Test
	public void testCalculateSum3() {
		// Aufgabe 2.1
		Node o1 = buildExample(null, null);
		Node origin = buildExample(o1, null);
		int res = NodeTree.calculateSum(origin);
		assertEquals(18, res);
	}
	
	@Test
	public void testCalculateSum4() {
		// Aufgabe 2.1
		Node o1 = buildSecond(null, null);
		Node origin = buildExample(o1, null);
		int res = NodeTree.calculateSum(origin);
		assertEquals(6, res);
	}
	
	@Test
	public void testCalculateSum5() {
		// Aufgabe 2.1
		Node o1 = buildSecond(null, null);
		Node origin = buildSecond(o1, null);
		int res = NodeTree.calculateSum(origin);
		assertEquals(-6, res);
	}

	@Test
	public void testHighestPath1() {
		// Aufgabe 2.2
		Node origin = buildExample(null, null);
		int res = NodeTree.highestPath(origin);
		assertEquals(11, res);
	}
	
	@Test
	public void testHighestPath2() {
		// Aufgabe 2.1
		Node origin = buildSecond(null, null);
		int res = NodeTree.highestPath(origin);
		assertEquals(7, res);
	}
	
	@Test
	public void testHighestPath3() {
		// Aufgabe 2.2
		Node o1 = buildExample(null, null);
		Node origin = buildExample(o1, null);
		int res = NodeTree.highestPath(origin);
		assertEquals(11, res);
	}
	
	@Test
	public void testHighestPath4() {
		// Aufgabe 2.2
		Node o1 = buildSecond(null, null);
		Node origin = buildExample(o1, null);
		int res = NodeTree.highestPath(origin);
		assertEquals(11, res);
	}
	
	@Test
	public void testHighestPath5() {
		// Aufgabe 2.2
		Node o1 = buildExample(null, null);
		Node origin = buildSecond(o1, null);
		int res = NodeTree.highestPath(origin);
		assertEquals(12, res);
	}
	
	
	public static Node[] buildExampleTriTree(Node o1, Node o2, int retPathTo) {
		// only used for tasks 2.3 and 2.4
		Node seven = new Node(7, o2, null);
		Node mtwo = new TriNode(-2, null, null, seven);
		Node one = new Node(1);
		Node four = new TriNode(4, mtwo, null, one);
		Node mthree = new TriNode(-3, null, null, o1);
		Node two = new Node(2, mthree, four);
		
		if(retPathTo==0 || retPathTo==2) {
			return new Node[] {two, four, mtwo, seven};
		} else {
			return new Node[] {two, mthree};
		}
		
	}

	public static Node[] buildSecondTriTree(Node o1, Node o2, int retPathTo) {
		Node msix = new Node(-6, null, o2);
		Node mone = new Node(-1);
		Node three = new TriNode(3, mone, null, msix);
		Node two = new Node(2, o1, null);
		Node zero = new Node(0, two, null);
		Node mten = new TriNode(-10, null, null, zero);
		Node four = new TriNode(4, mten, null, null);
		Node five = new TriNode(5, null, four, three);
		if(retPathTo==0) {
			return new Node[] {five, three, mone};
		} else if (retPathTo==1){
			return new Node[] {five, four, mten, zero, two};
		} else {
			return new Node[] {five, three, msix};
		}
	}
	
	@Test
	public void testCalculateTriSum1() {
		Node origin = buildExampleTriTree(null, null, 0)[0];
		int res = NodeTree.calculateTriSum(origin);
		assertEquals(9, res);
	}
	
	@Test
	public void testCalculateTriSum2() {
		Node origin = buildSecondTriTree(null, null, 0)[0];
		int res = NodeTree.calculateTriSum(origin);
		assertEquals(-3, res);
	}
	
	@Test
	public void testCalculateTriSum3() {
		Node o1 = buildSecondTriTree(null, null, 0)[0];
		Node origin = buildExampleTriTree(o1, null, 0)[0];
		int res = NodeTree.calculateTriSum(origin);
		assertEquals(6, res);
	}
	
	@Test
	public void testCalculateTriSum4() {
		Node o1 = buildExampleTriTree(null, null, 0)[0];
		Node origin = buildExampleTriTree(o1, null, 0)[0];
		int res = NodeTree.calculateTriSum(origin);
		assertEquals(18, res);
	}
	
	@Test
	public void testCalculateTriSum5() {
		Node o1 = buildSecondTriTree(null, null, 0)[0];
		Node origin = buildSecondTriTree(o1, null, 0)[0];
		int res = NodeTree.calculateTriSum(origin);
		assertEquals(-6, res);
	}
	
	@Test
	public void testHighestTriPath1() {
		Node[] correct = buildExampleTriTree(null, null, 0);
		Node origin = correct[0];
		Node[] res = NodeTree.highestTriPath(origin);
		assertArrayEquals(correct, res);
	}
	
	@Test
	public void testHighestTriPath2() {
		Node[] correct = buildSecondTriTree(null, null, 0);
		Node origin = correct[0];
		Node[] res = NodeTree.highestTriPath(origin);
		assertArrayEquals(correct, res);
	}
	
	@Test
	public void testHighestTriPath3() {
		Node[] correct2 = buildExampleTriTree(null, null, 0);
		Node[] correct1 = buildExampleTriTree(correct2[0], null, 0);
		Node origin = correct1[0];
		Node[] res = NodeTree.highestTriPath(origin);
		assertArrayEquals(correct1, res);
	}
	public Node[] concat(Node[] a1, Node[] a2) {
		Node[] res = new Node[a1.length+a2.length];
		for(int i=0; i<a1.length; i++)
			res[i] = a1[i];
		for(int i=0; i<a2.length; i++)
			res[a1.length+i] = a2[i];
		return res;
	}
	
	@Test
	public void testHighestTriPath4() {
		Node[] correct2 = buildSecondTriTree(null, null, 0);
		Node[] correct1 = buildExampleTriTree(null, correct2[0], 2);
		Node origin = correct1[0];
		Node[] res = NodeTree.highestTriPath(origin);
		assertArrayEquals(concat(correct1, correct2), res);
	}
	
	@Test
	public void testHighestTriPath5() {
		Node[] correct2 = buildExampleTriTree(null, null, 0);
		Node[] correct1 = buildSecondTriTree(null, correct2[0], 2);
		Node origin = correct1[0];
		Node[] res = NodeTree.highestTriPath(origin);
		assertArrayEquals(concat(correct1, correct2), res);
	}
}
