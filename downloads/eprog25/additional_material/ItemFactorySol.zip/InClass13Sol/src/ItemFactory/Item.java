package ItemFactory;

public class Item implements Comparable<Item>{
    ItemFactory itemFactory;
	private Level level;
	private int id;
	private int age;
	private int health;

	public Item(Level level, int id, int age, int health) {
		this.level = level;
		this.id = id;
		this.age = age;
		this.health = health;
	}

	public Level getLevel() { return level; }
	public int getID() { return id; }
	public int getAge() { return age; }
	public int getHealth() { return health; }

	public void setHealth(int newHealth) {
        if(health != newHealth){
            health = newHealth;
            itemFactory.reportHealth(this, newHealth);
        }
    }

    @Override
    public int compareTo(Item other) {
        return Integer.compare(this.id, other.id); // damit wir Treeset benutzen können
    }

    public boolean isRelated(Item other){
        return this.level.sumPoints() == other.level.sumPoints(); // per Aufgabenstellung
    }

}
