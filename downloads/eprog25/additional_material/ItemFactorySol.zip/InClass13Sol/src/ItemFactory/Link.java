package ItemFactory;

import java.util.List;

public class Link {
    List<Integer> ids;
    public Link(List<Integer> links){
        this.ids = links;
    }

    public boolean contains(int id){
        return ids.contains(id);
    }
}
