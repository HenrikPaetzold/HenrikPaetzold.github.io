package ItemFactory;

public class Declass extends Item{
    int targetId;

    public Declass(Level level, int id, int age, int health, int targetId, ItemFactory itemFactory) {
        super(level, id, age, health);
        this.targetId = targetId;
        this.itemFactory = itemFactory;
    }

    public int getAge() {
        return itemFactory.findTargetRec(null, targetId).getAge();
    }

    public int getHealth() {
        return itemFactory.findTargetRec(null, targetId).getHealth();
    }
}
