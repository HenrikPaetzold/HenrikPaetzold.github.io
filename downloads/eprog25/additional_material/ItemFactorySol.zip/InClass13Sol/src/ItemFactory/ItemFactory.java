package ItemFactory;

import java.util.LinkedList;
import java.util.TreeMap;

public class ItemFactory {
    TreeMap<Integer, Item> items = new TreeMap<>();
    LinkedList<Link> links = new LinkedList<>();

    public Item createItem(Level level, int id, int age, int health) {
        Item item = new Item(level, id, age, health);
        items.put(id, item);
        item.itemFactory = this;
        return item;
    }

    public Item createDeclass(Level level, int id, int targetId) {
        Item declass = new Declass(level, id, -1, -1, targetId, this);
        Item target = findTargetRec(declass, targetId);
        items.put(id, declass);
        return declass;
    }

    public Item findItem(int targetId){
        Item i = items.get(targetId);
        if(i == null) throw new IllegalArgumentException("Kein Item mit targetId");
        return i;
    }

    public Item findTargetRec(Item initial, int targetId){
        Item curr = findItem(targetId);
        if(initial != null && initial.isRelated(curr))throw new IllegalArgumentException("Siherheitslevel verwandt");
        if(curr instanceof Declass){
            curr = findTargetRec(initial, ((Declass)curr).targetId);
        }
        return curr;
    }

    public void reportHealth(Item caller, int newHealth){
        for(Link link : links){
            if(link.contains(caller.getID())){
                for(int id : link.ids){
                    items.get(id).setHealth(newHealth);
                }
            }
        }
    }
}
