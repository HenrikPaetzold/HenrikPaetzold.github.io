package CSite;

import java.util.Set;

public class CCompany {
		
	public CCompany() {
		// TODO
	}
	
	public Set<Resource> resources() {
		// TODO
		return null;
	}
	
	public void add(Resource resource) {
		// TODO
		return;
	}
	
	public void nextDay() {
		// TODO
		return;
	}
	
	public CSite createCSite(int type) {
		// Aendern Sie diese Methode, falls Sie Task (a) nicht geloest haben.
		return createCSite(Set.of(type), 2);
	}

	public CSite createCSite(Set<Integer> types, int limit) {
		// TODO
		return null;
	}
	
	public CSite createCSite(Set<Integer> types, int limit, int flowLimit) {
		// TODO
		return null;
	}
}



