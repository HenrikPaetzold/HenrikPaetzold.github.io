package CSite;

public interface Resource {
	public int type();
}
