package Rooms;

public class Room implements Comparable<Room>{
	int age;
	public int[] doorsTo;

	public Room(int age, int[] doorsTo) {
		this.age = age;
		this.doorsTo = doorsTo;
	}

	public boolean isExit() {
		return doorsTo.length == 0;
	}

	public int getAge() {
		return age;
	}

    @Override
    public int compareTo(Room other) {
        if(this.doorsTo.length < other.doorsTo.length)return -1;
        if(this.doorsTo.length > other.doorsTo.length)return 1;
        if(this.age < other.age)return -1;
        if(this.age > other.age)return 1;
        return 0;
    }

    public String toString(){
        return ""+doorsTo.length;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof Room && this.age == ((Room)obj).age;
    }


    @Override
    public int hashCode() {
        return Integer.hashCode(age);
    }
}
