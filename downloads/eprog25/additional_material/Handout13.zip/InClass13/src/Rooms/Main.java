package Rooms;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Room r1 = new Room(0, new int[]{3, 2, 1});
        Room r2 = new Room(5, new int[]{3, 2, 4});
        Room r3 = new Room(2, new int[]{1});
        Room r4 = new Room(7, new int[]{3, 2, 1, 0});
        Room r5 = new Room(1, new int[]{});
        Room r6 = new Room(1, new int[]{1,2});

        Room[] rooms = { r1, r2, r3, r4, r5, r6 };

        System.out.println("Vor Sortierung:");
        for (Room r : rooms) {
            System.out.println(r);
        }

        //Arrays.sort(rooms);

        Comparator<Room> c1 = new Comparator<>(){
            @Override
            public int compare(Room o1, Room o2) {
                if(o1.doorsTo.length < o2.doorsTo.length)return 1;
                if(o1.doorsTo.length > o2.doorsTo.length)return -1;
                if(o1.age < o2.age)return 1;
                if(o1.age > o2.age)return -1;
                return 0;
            }
        };

        //Arrays.sort(rooms, c1);

        Arrays.sort(rooms, Collections.reverseOrder());

        System.out.println("\nNach lexikographischer Sortierung:");
        for (Room r : rooms) {
            System.out.println(r);
        }

        TreeSet<Room> s1 = new TreeSet<>();
        HashSet<Room> h1 = new HashSet<>();

        for(Room room : rooms){
            h1.add(room);
            s1.add(room);
        }

        System.out.println("HashSet Size: "+h1.size());
        System.out.println("TreeSet Size: "+s1.size());
    }
}
