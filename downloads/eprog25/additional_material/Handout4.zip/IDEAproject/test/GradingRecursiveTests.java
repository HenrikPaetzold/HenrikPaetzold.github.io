import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class GradingRecursiveTests {

    // -------- sum --------
    @Test public void sum_empty() { assertEquals(0, RecTasks.sum(new int[]{})); }
    @Test public void sum_single() { assertEquals(7, RecTasks.sum(new int[]{7})); }
    @Test public void sum_threePositive() { assertEquals(8, RecTasks.sum(new int[]{2,5,1})); }
    @Test public void sum_negativesMixed() { assertEquals(-4, RecTasks.sum(new int[]{-3,1,-2})); }
    @Test public void sum_zeros() { assertEquals(0, RecTasks.sum(new int[]{0,0,0})); }
    @Test public void sum_largeCancellation() { assertEquals(1_000_000, RecTasks.sum(new int[]{1_000_000,-1,1})); }

    // -------- count --------
    @Test public void count_emptyString() { assertEquals(0, RecTasks.count('x', "")); }
    @Test public void count_banane_a() { assertEquals(2, RecTasks.count('a', "banane")); }
    @Test public void count_banane_z() { assertEquals(0, RecTasks.count('z', "banane")); }
    @Test public void count_case_A_in_AaAa() { assertEquals(2, RecTasks.count('A', "AaAa")); }
    @Test public void count_case_a_in_AaAa() { assertEquals(2, RecTasks.count('a', "AaAa")); }
    @Test public void count_manyXs() { assertEquals(4, RecTasks.count('x', "xxxx")); }
    @Test public void count_pattern() { assertEquals(3, RecTasks.count('b', "abcabcabc")); }

    // -------- isSorted (non-decreasing) --------
    @Test public void isSorted_empty() { assertTrue(RecTasks.isSorted(new int[]{})); }
    @Test public void isSorted_single() { assertTrue(RecTasks.isSorted(new int[]{5})); }
    @Test public void isSorted_allEqual() { assertTrue(RecTasks.isSorted(new int[]{1,1,1,1})); }
    @Test public void isSorted_withEquals() { assertTrue(RecTasks.isSorted(new int[]{1,2,2,5})); }
    @Test public void isSorted_negativesAndZeros() { assertTrue(RecTasks.isSorted(new int[]{-3,-3,-1,0,0,7})); }
    @Test public void isSorted_false_simpleSwap() { assertFalse(RecTasks.isSorted(new int[]{2,1})); }
    @Test public void isSorted_false_midInversion() { assertFalse(RecTasks.isSorted(new int[]{1,3,2,4})); }
    @Test public void isSorted_false_startInversion() { assertFalse(RecTasks.isSorted(new int[]{5,1,2,3})); }
    @Test public void isSorted_false_endInversion() { assertFalse(RecTasks.isSorted(new int[]{1,2,3,0})); }

    // -------- dedupRuns --------
    @Test public void dedup_empty() { assertEquals("", RecTasks.dedupRuns("")); }
    @Test public void dedup_single() { assertEquals("x", RecTasks.dedupRuns("x")); }
    @Test public void dedup_allSame() { assertEquals("x", RecTasks.dedupRuns("xxx")); }
    @Test public void dedup_basic() { assertEquals("abca", RecTasks.dedupRuns("aabbcca")); }
    @Test public void dedup_alternating() { assertEquals("ababab", RecTasks.dedupRuns("ababab")); }
    @Test public void dedup_edgesBlock() { assertEquals("abca", RecTasks.dedupRuns("aaabcccaaa")); }
    @Test public void dedup_abba() { assertEquals("aba", RecTasks.dedupRuns("abba")); }
    @Test public void dedup_aabbaa() { assertEquals("aba", RecTasks.dedupRuns("aabbaa")); }
    @Test public void dedup_mississippi() { assertEquals("misisipi", RecTasks.dedupRuns("mississippi")); }

    // -------- balancedStrings --------
    @Test public void curlyPair_true() { assertTrue(RecTasks.isBalanced("{}")); }
    @Test public void nestedCurly_true() { assertTrue(RecTasks.isBalanced("{{}}")); }
    @Test public void mixedIndependent_true() { assertTrue(RecTasks.isBalanced("{}")); }
    @Test public void mixedNested_true() { assertTrue(RecTasks.isBalanced("{}")); }
    @Test public void curlyMissingClose_false() { assertFalse(RecTasks.isBalanced("{{}")); }
    @Test public void curlyMissingOpen_false() { assertFalse(RecTasks.isBalanced("{}}")); }
    @Test public void curlyStartsWithClose_false() { assertFalse(RecTasks.isBalanced("}{")); }
    @Test public void curlyAndRoundUnbalanced_true() { assertTrue(RecTasks.isBalanced("{}")); }

    // Optional: Kombination mit ignorierten Zeichen
    @Test public void mixedWithText_true() { assertTrue(RecTasks.isBalanced("{b}")); }
    @Test public void mixedWithText_false() { assertFalse(RecTasks.isBalanced("a{")); }

}