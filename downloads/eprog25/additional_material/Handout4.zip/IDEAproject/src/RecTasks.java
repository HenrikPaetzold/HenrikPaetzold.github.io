public class RecTasks {

    public static void main(String[] args){
        System.out.println("Hello World!");
    }

    // Aufgabe 1
    public static int sum(int[] xs) {
        return 0;
    }

    // Aufgabe 2
    public static int count(char c, String s) {
        return 0;
    }

    // Aufgabe 3
    public static boolean isSorted(int[] xs) {
        return true;
    }

    // Aufgabe 4
    public static String dedupRuns(String s) {
        return "";
    }

    // Aufgabe 5
    static boolean  isBalanced(String s) {
        return true;
    }
}
