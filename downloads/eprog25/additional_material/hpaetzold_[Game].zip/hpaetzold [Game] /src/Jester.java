public class Jester extends Human {
    public Jester(int health, int position) {
        super(health, position);
    }
}