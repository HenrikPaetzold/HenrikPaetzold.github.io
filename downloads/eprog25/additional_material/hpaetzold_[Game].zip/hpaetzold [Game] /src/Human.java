
public class Human {

	public int health, position;

    public Human(int health, int position){
        this.health = health;
        this.position = position;
    }
	
	public int getHealth() {
		return health;
	}
	
	public int getPosition() {
		return position;
	}
	
	public boolean isAlive() {
		return health > 0;
	}
	
	public boolean scheduleAction(Action action) {
		return this.isAlive();
	}

    public void perform(Action action){
        return;
    }
}
