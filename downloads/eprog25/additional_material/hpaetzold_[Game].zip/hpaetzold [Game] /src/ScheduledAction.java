class ScheduledAction {
    Human source;
    Action action;
    int delay;
    boolean active = true;

    public ScheduledAction(Human source, Action action, int delay){
        this.source =source;
        this.action = action;
        this.delay = delay;
    }
}