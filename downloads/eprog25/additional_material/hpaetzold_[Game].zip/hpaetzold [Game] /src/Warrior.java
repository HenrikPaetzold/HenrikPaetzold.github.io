public class Warrior extends Human{
    Game game;
    boolean scheduledNextRound;
    public Warrior(int health, int position, Game game) {
        super(health, position);
        this.game = game;
    }

    @Override
    public boolean scheduleAction(Action action){
        if(!isAlive())return false;
        int delay = action == Action.ATTACK ? 0 : 1;
        game.addAction(this, action, delay);
        return true;
    }

    public void perform(Action action){
        if(action == Action.SUMMON){
            health -= 5;
        }else if(action == Action.ATTACK){
            game.attackOnField(position, 10);
        }
    }

}
