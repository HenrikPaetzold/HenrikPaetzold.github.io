public class Game {
    Human[] players = new Human[100];
    ScheduledAction[] actions = new ScheduledAction[1000];
    int noPlayers = 0;
    int numActions = 0;

    void advanceTurn() {
        for (int i = 0; i < numActions; i++) {
            ScheduledAction sa = actions[i];
            if (!sa.active) continue;
            if (!sa.source.isAlive()) {
                sa.active = false;
                continue;
            }

            if (sa.delay > 0) {
                sa.delay--;
            } else {
                sa.source.perform(sa.action);
                sa.active = false;
            }
        }
    }


    Human createJester(int health, int position) {
		Human jester = new Jester(health, position);
        players[noPlayers++] = jester;
		return jester;
	}
	
	Human createWarrior(int health, int position) {
        Human warrior = new Warrior(health, position, this);
        players[noPlayers++] = warrior;
        return warrior;
	}
	
	Human createCleric(int health, int position) {
        Human cleric = new Cleric(health, position, this);
        players[noPlayers++] = cleric;
        return cleric;
	}

    public void attackOnField(int field, int damage){
        int f1 = field + 1;
        int f2 = field - 1;
        for(Human h : players){
            if(h==null)break;
            if(!h.isAlive())continue;
            if(h.position == f1 || h.position == f2)h.health -= damage;
        }
    }

    public void movePlayers(int field){
        int[] positions = {field+3, field+4, field+5, field-3, field-4, field-5};
        for(int pos : positions){
            for(Human h : players){
                if(h==null)break;
                if(!h.isAlive())continue;
                if(h.position == pos)h.position = field;
            }
        }
    }

    public void addAction(Human source, Action action, int delay) {
        actions[numActions++] = new ScheduledAction(source, action, delay);

    }
}
