
public enum Action {
	ATTACK,
	SUMMON
}
