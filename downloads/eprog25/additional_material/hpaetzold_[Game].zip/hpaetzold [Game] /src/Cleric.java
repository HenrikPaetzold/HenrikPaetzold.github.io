public class Cleric extends Human{
    Game game;
    public Cleric(int health, int position, Game game) {
        super(health, position);
        this.game = game;
    }

    @Override
    public boolean scheduleAction(Action action){
        if(!isAlive())return false;
        int delay = action == Action.ATTACK ? 0 : 2;
        game.addAction(this, action, delay);
        return true;
    }

    public void perform(Action action){
        if(action == Action.ATTACK){
            game.attackOnField(position, 3);
        }else if(action == Action.SUMMON){
            game.movePlayers(position);
        }
    }
}
