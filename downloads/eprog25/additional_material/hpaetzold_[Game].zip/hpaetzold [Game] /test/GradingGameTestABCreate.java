import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GradingGameTestABCreate {

    // NICHT DIE OFFIZIELLEN GRADING TESTS - ABGEÄNDERT AUS DEN COMMUNITY SOLUTIONS ÜBERNOMMEN

	/********** a) **********/
	
	@Test
	public void testAACreateWarrior() {
		Game game = new Game();
		Human h1 = game.createWarrior(120, 35);
		
		assertNotNull(h1);
		
		assertEquals(120, h1.getHealth());
		assertEquals(35, h1.getPosition());
	}
	
	/********** b) **********/
	
	@Test
	public void testBACreateCleric() {
		Game game = new Game();
		Human h1 = game.createCleric(200, 20);
		
		assertNotNull(h1);
		
		assertEquals(200, h1.getHealth());
		assertEquals(20, h1.getPosition());
	}
	
}
