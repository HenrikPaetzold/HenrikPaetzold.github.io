import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GradingGameTestAB {

    // NICHT DIE OFFIZIELLEN GRADING TESTS - ABGEÄNDERT AUS DEN COMMUNITY SOLUTIONS ÜBERNOMMEN
	
	@Test
	public void testAACreateWarrior() {
		Game game = new Game();
		Human h1 = game.createWarrior(120, 35);
		
		assertNotNull(h1);
		
		assertEquals(120, h1.getHealth());
		assertEquals(35, h1.getPosition());
	}

	@Test
	public void testAWarriorAttack01Given() {
		Game game = new Game();
		Human h1 = game.createWarrior(100, 9);
		Human h2 = game.createWarrior(100, 10);
		Human h3 = game.createWarrior(100, 10);
		Human h4 = game.createWarrior(100, 11);
		Human h5 = game.createWarrior(100, 12);

		h1.scheduleAction(Action.ATTACK);
		h2.scheduleAction(Action.ATTACK);

		// action is not yet executed
		assertEquals(100, h1.getHealth());
		assertEquals(100, h2.getHealth());
		assertEquals(100, h3.getHealth());
		assertEquals(100, h4.getHealth());
		assertEquals(100, h5.getHealth());

		game.advanceTurn();

		// attacks are executed
		assertEquals(90, h1.getHealth()); // hit by h2
		assertEquals(90, h2.getHealth()); // hit by h1
		assertEquals(90, h3.getHealth()); // hit by h1
		assertEquals(90, h4.getHealth()); // hit by h2
		assertEquals(100, h5.getHealth());
	}
	
	@Test
	public void testAWarriorAttack02() {
		Game game = new Game();
		Human h1 = game.createWarrior(105, 9);
		Human h2 = game.createWarrior(121, 10);
		
		h1.scheduleAction(Action.ATTACK);
		game.advanceTurn();
		
		assertEquals(105, h1.getHealth());
		assertEquals(111, h2.getHealth());
	}

	@Test
	public void testAWarriorAttack03() {
		Game game = new Game();

		Human h1 = game.createWarrior(50, 994);
		Human h2 = game.createWarrior(50, 993);
		Human h3 = game.createWarrior(20, 6);
		Human h4 = game.createWarrior(21, 7);

		h1.scheduleAction(Action.ATTACK);
		h3.scheduleAction(Action.ATTACK);

		assertEquals(50, h1.getHealth());
		assertEquals(50, h2.getHealth());
		assertEquals(20, h3.getHealth());
		assertEquals(21, h4.getHealth());

		game.advanceTurn();

		assertEquals(50, h1.getHealth());
		assertEquals(40, h2.getHealth());
		assertEquals(20, h3.getHealth());
		assertEquals(11, h4.getHealth());

		h3.scheduleAction(Action.ATTACK);
		h2.scheduleAction(Action.ATTACK);

		assertEquals(50, h1.getHealth());
		assertEquals(40, h2.getHealth());
		assertEquals(20, h3.getHealth());
		assertEquals(11, h4.getHealth());

		game.advanceTurn();

		assertEquals(40, h1.getHealth());
		assertEquals(40, h2.getHealth());
		assertEquals(20, h3.getHealth());
		assertEquals(1, h4.getHealth());
	}

	@Test
	public void testAWarriorAttack04() {
		Game game = new Game();

		Human w1 = game.createWarrior(10, 10);
		Human w2 = game.createWarrior(10, 11);

		w1.scheduleAction(Action.ATTACK);
		w2.scheduleAction(Action.ATTACK);
		game.advanceTurn();

		assertEquals(0, w2.getHealth()); // w2 not alive after w1's action
		assertEquals(10, w1.getHealth());
	}

	@Test
	public void testAWarriorAttack05() {
		Game game = new Game();

		Human w1 = game.createWarrior(20, 50);
		Human w2 = game.createWarrior(20, 50);
		Human w3 = game.createWarrior(21, 51);

		w1.scheduleAction(Action.ATTACK);
		w2.scheduleAction(Action.ATTACK);
		game.advanceTurn();

		assertEquals(20, w1.getHealth());
		assertEquals(20, w2.getHealth());
		assertEquals(1, w3.getHealth());
	}

	@Test
	public void testAWarriorAttack06() {
		Game game = new Game();

		Human h1 = game.createWarrior(200, 20);

		Human h3 = game.createWarrior(200, 19);
		Human h4 = game.createWarrior(20, 21);

		h1.scheduleAction(Action.ATTACK);
		game.advanceTurn();

		assertEquals(200, h1.getHealth());
		assertEquals(190, h3.getHealth());
		assertEquals(10, h4.getHealth());
	}

	@Test
	public void testAWarriorSummon01Given() {
		Game game = new Game();
		Human h1 = game.createWarrior(100, 9);
		Human h2 = game.createWarrior(100, 10);

		h1.scheduleAction(Action.SUMMON);

		game.advanceTurn();

		assertEquals(100, h1.getHealth());
		assertEquals(100, h2.getHealth());

		h2.scheduleAction(Action.SUMMON);

		game.advanceTurn();

		assertEquals(95, h1.getHealth());
		assertEquals(100, h2.getHealth());

		game.advanceTurn();

		assertEquals(95, h1.getHealth());
		assertEquals(95, h2.getHealth());
	}

	@Test
	public void testAWarriorSummon02() {
		Game game = new Game();

		Human h1 = game.createWarrior(50, 994);
		Human h2 = game.createWarrior(50, 993);
		Human h3 = game.createWarrior(20, 6);
		Human h4 = game.createWarrior(20, 7);

		h1.scheduleAction(Action.SUMMON);
		h3.scheduleAction(Action.SUMMON);
		game.advanceTurn();

		h2.scheduleAction(Action.SUMMON);
		game.advanceTurn();

		game.advanceTurn();

		assertEquals(45, h1.getHealth());
		assertEquals(45, h2.getHealth());
		assertEquals(15, h3.getHealth());
		assertEquals(20, h4.getHealth());
	}

	@Test
	public void testAWarriorSummon03() {
		Game game = new Game();

		Human h1 = game.createWarrior(100, 300);
		Human h2 = game.createWarrior(100, 300);
		Human h3 = game.createWarrior(100, 300);

		h1.scheduleAction(Action.SUMMON);
		game.advanceTurn();

		assertEquals(100, h1.getHealth());
		assertEquals(100, h2.getHealth());
		assertEquals(100, h3.getHealth());

		game.advanceTurn();

		assertEquals(95, h1.getHealth());
		assertEquals(100, h2.getHealth());
		assertEquals(100, h3.getHealth());

		h3.scheduleAction(Action.SUMMON);
		game.advanceTurn();

		assertEquals(95, h1.getHealth());
		assertEquals(100, h2.getHealth());
		assertEquals(100, h3.getHealth());

		game.advanceTurn();

		assertEquals(95, h1.getHealth());
		assertEquals(100, h2.getHealth());
		assertEquals(95, h3.getHealth());
	}

	@Test
	public void testAWarriorZMixed01() {
		Game game = new Game();

		Human h1 = game.createWarrior(20, 10);
		Human h2 = game.createWarrior(10, 11);

		h1.scheduleAction(Action.SUMMON);
		game.advanceTurn();
		assertEquals(20, h1.getHealth());
		game.advanceTurn();
		assertEquals(15, h1.getHealth());

		h2.scheduleAction(Action.SUMMON);
		h1.scheduleAction(Action.ATTACK);

		game.advanceTurn();

		assertEquals(15, h1.getHealth());
		assertEquals(0, h2.getHealth());

		game.advanceTurn();

		// Make sure that the summon was not executed, since h2 is not alive
		assertEquals(15, h1.getHealth());
		assertEquals(0, h2.getHealth());
	}

	@Test
	public void testAWarriorZMixed02() {
		Game game = new Game();

		Human h1 = game.createWarrior(20, 10);
		Human h2 = game.createWarrior(20, 10);
		Human h3 = game.createWarrior(16, 11);
		Human h4 = game.createWarrior(10, 14);
		Human h5 = game.createWarrior(15, 15);


		h1.scheduleAction(Action.ATTACK);
		h3.scheduleAction(Action.SUMMON);
		h4.scheduleAction(Action.ATTACK);
		h5.scheduleAction(Action.ATTACK);

		game.advanceTurn();

		assertEquals(20, h1.getHealth());
		assertEquals(20, h2.getHealth());
		assertEquals(6, h3.getHealth());
		//h4 first attacks h5 before h5's action
		assertEquals(5, h5.getHealth());

		game.advanceTurn();

		assertEquals(20, h1.getHealth());
		assertEquals(20, h2.getHealth());
		assertEquals(1, h3.getHealth());
		assertEquals(5, h5.getHealth());		
	}

	
	/********** b) **********/
	
	@Test
	public void testBACreateCleric() {
		Game game = new Game();
		Human h1 = game.createCleric(200, 20);
		
		assertNotNull(h1);
		
		assertEquals(200, h1.getHealth());
		assertEquals(20, h1.getPosition());
	}
		
	/** Cleric **/
	
	//Cleric Attack	
	
	@Test
	public void testBClericAttack01() {
		Game game = new Game();
		
		Human h1 = game.createCleric(152, 6);
		Human h2 = game.createCleric(154, 7);
		Human h3 = game.createCleric(180, 8);
		Human h4 = game.createCleric(140, 9);
		
		h2.scheduleAction(Action.ATTACK);		
		game.advanceTurn();
		
		assertEquals(149, h1.getHealth());
		assertEquals(154, h2.getHealth());
		assertEquals(177, h3.getHealth());
		assertEquals(140, h4.getHealth());		
	}
	
	@Test
	public void testBClericAttack02() {
		Game game = new Game();

		Human h1 = game.createCleric(101, 12);
		Human h2 = game.createCleric(102, 15);
		Human h3 = game.createCleric(103, 15);
		Human h4 = game.createCleric(104, 15);
		Human h5 = game.createCleric(105, 14);
		Human h6 = game.createCleric(106, 13);
		Human h7 = game.createCleric(107, 13);
		Human h8 = game.createCleric(108, 25);

		
		h5.scheduleAction(Action.ATTACK);
		game.advanceTurn();
		
		assertEquals(101, h1.getHealth());
		assertEquals(99,  h2.getHealth());
		assertEquals(100, h3.getHealth());
		assertEquals(101, h4.getHealth());		
		assertEquals(105, h5.getHealth());		
		assertEquals(103, h6.getHealth());		
		assertEquals(104, h7.getHealth());
		assertEquals(108, h8.getHealth());
	}
	
	@Test
	public void testBClericAttack03() {
		Game game = new Game();
		
		Human h1 = game.createCleric(80,  12);
		Human h2 = game.createCleric(102, 14);
		Human h3 = game.createCleric(103, 15);
		Human h4 = game.createCleric(104, 16);

		h2.scheduleAction(Action.ATTACK);
		h3.scheduleAction(Action.ATTACK);
		game.advanceTurn();
		
		assertEquals(80, h1.getHealth());
		assertEquals(99, h2.getHealth());
		assertEquals(100, h3.getHealth());
		assertEquals(101, h4.getHealth());
	}
	
	//Cleric Summon
	
	@Test
	public void testBClericSummon01() {
		Game game = new Game();
		
		Human h1 = game.createCleric(80,  11);
		Human h2 = game.createCleric(80,  12);
		Human h3 = game.createCleric(80,  13);
		Human h4 = game.createCleric(102, 14);
		Human h5 = game.createCleric(104, 15);
		Human h6 = game.createCleric(104, 16);
		
		Human h7 = game.createCleric(104, 17);
		
		Human h8 = game.createCleric(104, 18);
		Human h9 = game.createCleric(104, 19);
		Human h10 = game.createCleric(104, 20);
		Human h11 = game.createCleric(104, 21);
		Human h12 = game.createCleric(104, 22);
		Human h13 = game.createCleric(104, 23);

		
		h7.scheduleAction(Action.SUMMON);
		
		game.advanceTurn();
		game.advanceTurn();
		game.advanceTurn();
		
		assertEquals(11,  h1.getPosition());
		
		assertEquals(17,  h2.getPosition());
		assertEquals(17,  h3.getPosition());
		assertEquals(17, h4.getPosition());
		
		assertEquals(15, h5.getPosition());		
		assertEquals(16, h6.getPosition());		
		
		assertEquals(17, h7.getPosition());
		
		assertEquals(18, h8.getPosition());
		assertEquals(19, h9.getPosition());
		
		assertEquals(17, h10.getPosition());
		assertEquals(17, h11.getPosition());
		assertEquals(17, h12.getPosition());
		
		assertEquals(23, h13.getPosition());
	}
	
	@Test
	public void testBClericSummon02() {
		Game game = new Game();
		
		Human h1 = game.createCleric(50, 10);
		Human h2 = game.createCleric(50, 13);
		Human h3 = game.createCleric(50, 16);
		
		h1.scheduleAction(Action.SUMMON);
		
		game.advanceTurn();
		
		assertEquals(10, h1.getPosition());
		assertEquals(13, h2.getPosition());
		assertEquals(16, h3.getPosition());
		
		game.advanceTurn();

		assertEquals(10, h1.getPosition());
		assertEquals(13, h2.getPosition());
		assertEquals(16, h3.getPosition());

		game.advanceTurn();
		
		assertEquals(10, h1.getPosition());
		assertEquals(10, h2.getPosition());
		assertEquals(16, h3.getPosition());
	}
	
	@Test
	public void testBClericSummon03() {
		Game game = new Game();
		
		Human h1 = game.createCleric(50, 22);
		Human h2 = game.createCleric(50, 23);
		Human h3 = game.createCleric(50, 19);
		
		Human i1 = game.createCleric(50, 45);
		Human i2 = game.createCleric(50, 44);
		Human i3 = game.createCleric(50, 42);
		
		h1.scheduleAction(Action.SUMMON);
		i1.scheduleAction(Action.SUMMON);
		
		game.advanceTurn();
		game.advanceTurn();
		game.advanceTurn();
		
		assertEquals(22, h1.getPosition());
		assertEquals(23, h2.getPosition());
		assertEquals(22, h3.getPosition());
		
		assertEquals(45, i1.getPosition());
		assertEquals(44, i2.getPosition());
		assertEquals(45, i3.getPosition());
	}

	@Test
	public void testBClericSummon04() {
		Game game = new Game();
		
		Human h1 = game.createCleric(50, 17);
		Human h2 = game.createCleric(50, 35);
		Human h3 = game.createCleric(50, 19);
		Human h4 = game.createCleric(50, 21);
		Human h5 = game.createCleric(50, 22);
		Human h6 = game.createCleric(50, 24);


		h1.scheduleAction(Action.SUMMON);
		
		game.advanceTurn();
		
		h3.scheduleAction(Action.SUMMON);
		
		game.advanceTurn();
		
		game.advanceTurn();
		
		assertEquals(17, h1.getPosition());
		assertEquals(35, h2.getPosition());
		assertEquals(19, h3.getPosition());
		assertEquals(17, h4.getPosition());
		assertEquals(17, h5.getPosition());
		assertEquals(24, h6.getPosition());
		
		game.advanceTurn();

		assertEquals(17, h1.getPosition());
		assertEquals(35, h2.getPosition());
		assertEquals(19, h3.getPosition());
		assertEquals(17, h4.getPosition());
		assertEquals(17, h5.getPosition());
		assertEquals(19, h6.getPosition());
	}
	
	// Cleric Attack + Summon
	
	@Test
	public void testBClericZAttackSummon01() {		
		Game game = new Game();
		
		Human h1 = game.createCleric(2, 11);
		Human h2 = game.createCleric(205, 12);
		Human h3 = game.createCleric(210, 16);
		
		h3.scheduleAction(Action.SUMMON);		
		h2.scheduleAction(Action.ATTACK);
		
		game.advanceTurn();
		
		assertTrue(h1.getHealth() <= 0);
		assertEquals(205, h2.getHealth());
		assertEquals(210, h3.getHealth());
		
		assertEquals(11, h1.getPosition());
		assertEquals(12, h2.getPosition());
		assertEquals(16, h3.getPosition());
		
		game.advanceTurn();
		game.advanceTurn();
		
		assertEquals(11, h1.getPosition()); //not summoned, since h1 is not alive
		assertEquals(16, h2.getPosition());
		assertEquals(16, h2.getPosition());
	}
	// Mixed
	
	@Test
	public void testBZMixed01GivenFix() {
		Game game = new Game();
		Human h1 = game.createWarrior(100, 6);
		Human h2 = game.createCleric(100, 11);
		Human h3 = game.createWarrior(100, 12);
		Human h4 = game.createWarrior(100, 16);
		
		h2.scheduleAction(Action.SUMMON);
		
		game.advanceTurn();
		game.advanceTurn();
		
		h1.scheduleAction(Action.ATTACK);
		h3.scheduleAction(Action.ATTACK);
		
		game.advanceTurn();
		
		assertEquals(11, h1.getPosition());
		assertEquals(11, h4.getPosition());
		
		assertEquals(90, h1.getHealth());
		assertEquals(90, h2.getHealth());
		assertEquals(90, h3.getHealth());
		assertEquals(90, h4.getHealth());
	}
	
}
