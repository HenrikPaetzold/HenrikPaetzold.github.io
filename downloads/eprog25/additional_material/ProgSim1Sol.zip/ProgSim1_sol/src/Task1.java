import java.util.Arrays;

public class Task1 {

    public static void main(String[] args) {
		int[] input = new int[] {1,1,1,5,4};
		int[] res = Task1.rightDistance(input);
        System.out.println(Arrays.toString(res));
    }
    
    public static int[] rightDistance(int[] input) {
    	int[] res = new int[input.length];
        int maxIndex = input.length-1;
        int max = input[maxIndex];
        res[input.length - 1] = -1;
        for(int i = input.length - 2; i >= 0; i--){
            res[i] = Math.abs(i-maxIndex);
            if(input[i] >= max){
                max = input[i];
                maxIndex = i;
            }
        }
    	return res;
    }
}
