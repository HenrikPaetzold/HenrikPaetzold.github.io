/*
 * You MAY modify this file but do NOT remove, rename or change types of existing fields, methods, and constructors
 */
public class MultiplaneCamera {

	ImageFrame background;

    ImageFrame[] frames = new ImageFrame[11];

	public MultiplaneCamera(ImageFrame background) {
		this.background = background;
	}

	public void insertPlane(int height, int x0, int y0, int x1, int y1, int r, int g, int b) {
		if(frames[height] == null){
            Pixel[][] frame = new Pixel[background.frame.length][background.frame[0].length];
            ImageFrame temp = new ImageFrame(frame);
            if(x1 == -1 && y1 == -1){
                temp.drawDiagonal(x0,y0,r,g,b);
            }else {
                temp.fillRectangle(x0,y0,x1,y1,r,g,b);
            }
            frames[height] = temp;
        }
		
	}

	public ImageFrame getPhoto(int height) {
        if(frames[height]!=null)return null;
        Pixel[][] res = new Pixel[background.frame.length][background.frame[0].length];
        for(int i = 0; i < res.length; i++){
            for(int j = 0; j < res[0].length; j++){
                Pixel curr = background.frame[i][j];
                res[i][j] = new Pixel(curr.r, curr.g, curr.b);
            }
        }
        for(int h = 0; h < height; h++){
            for(int i = 0; i < res.length; i++){
                for(int j = 0; j < res[0].length; j++){
                    if(frames[h]==null)continue;
                    Pixel curr = frames[h].frame[i][j];
                    if(curr != null)res[i][j] = new Pixel(curr.r, curr.g, curr.b);
                }
            }
        }
		return new ImageFrame(res);
	}
}
