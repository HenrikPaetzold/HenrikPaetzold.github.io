/*
 * You MAY modify this file but do NOT remove, rename or change types of existing fields, methods, and constructors
 */
public class ImageFrame {
	
	Pixel[][] frame;
	
	public ImageFrame(Pixel[][] frame) {
		this.frame = frame;
	}

	public void fillRectangle(int x0, int y0, int x1, int y1, int r, int g, int b) {
        for(int i = x0; i <= x1; i++){
            for(int j = y0; j <= y1; j++){
                frame[i][j] = new Pixel(r,g,b);
            }
        }

	}
	
	public void drawDiagonal(int x0, int y0, int r, int g, int b) {
        int j = y0;
        for(int i = x0; i < frame.length; i++){
            if(j >= frame[i].length) break;
            frame[i][j] = new Pixel(r,g,b);
            j++;
        }
	}

}
