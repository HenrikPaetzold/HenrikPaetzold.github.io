/*
 * You may use this file to play around with your task 2 implementations. You can do whatever you want with this file.
 */

import java.util.Arrays;

public class Task2 {

	public static void main(String[] args) {
			ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(255,0,0), new Pixel(255,0,0),new Pixel(255,0,0)},
				{new Pixel(255,0,0), new Pixel(255,0,0),new Pixel(255,0,0)},
				{new Pixel(255,0,0), new Pixel(255,0,0),new Pixel(255,0,0)}});
			
			frame.fillRectangle(0, 0, 1, 1, 255, 255, 255);			
			frame.drawDiagonal(1, 0, 0, 0, 255);
			
			MultiplaneCamera cam = new MultiplaneCamera(frame);
			cam.insertPlane(5, 0, 0, 1, 2, 0, 0, 0);
			cam.insertPlane(7, 1, 1, -1, -1, 0, 255, 0);
			cam.insertPlane(10, 1, 1, -1, -1, 0, 0, 0);
			ImageFrame photo = cam.getPhoto(8);
			Arrays.toString(photo.frame);
	}

}
