import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Task2GradingTest2 {

    @Test
    public void test2aFillRectangle() {
        ImageFrame frame = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        frame.fillRectangle(1, 0, 2, 1, 255, 255, 255);
        frame.fillRectangle(0, 1, 1, 1, 0, 100, 0);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(0, 100, 0)},
                        {new Pixel(255, 255, 255), new Pixel(0, 100, 0)},
                        {new Pixel(255, 255, 255), new Pixel(255, 255, 255)}});

        assertArrayEquals(target.frame, frame.frame);
    }

    @Test
    public void test2aDrawDiagonal() {
        ImageFrame frame = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 255, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        frame.drawDiagonal(0, 1, 0, 0, 255);
        frame.drawDiagonal(1, 0, 0, 0, 100);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(0, 0, 255), new Pixel(0, 0, 0)},
                        {new Pixel(0, 0, 100), new Pixel(0, 0, 0), new Pixel(0, 0, 255)},
                        {new Pixel(0, 255, 0), new Pixel(0, 0, 100), new Pixel(0, 0, 0)}});

        assertArrayEquals(target.frame, frame.frame);
    }

    @Test
    public void test2aIndependentPixels() {
        ImageFrame frame = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        frame.fillRectangle(0, 0, 1, 1, 100, 0, 0);
        frame.frame[0][0].r = 0;

        ImageFrame target = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(100, 0, 0)},
                        {new Pixel(100, 0, 0), new Pixel(100, 0, 0)}});

        assertArrayEquals(target.frame, frame.frame);
    }

    @Test
    public void test2bSimple() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(0, 0, 0, 1, 2, 30, 50, 40);
        cam.insertPlane(2, 0, 1, -1, -1, 0, 0, 0);
        cam.insertPlane(9, 1, 1, -1, -1, 0, 1, 0);
        ImageFrame photo = cam.getPhoto(5);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{{new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(30, 50, 40), new Pixel(0, 0, 0)},
                        {new Pixel(30, 50, 40), new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        assertArrayEquals(target.frame, photo.frame);
    }

    @Test
    public void test2bDoubleInsert() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(5, 0, 0, 1, 1, 0, 50, 40);
        cam.insertPlane(9, 1, 1, -1, -1, 0, 1, 0);
        cam.insertPlane(5, 0, 1, -1, -1, 10, 10, 0);
        ImageFrame photo = cam.getPhoto(7);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 50, 40), new Pixel(0, 50, 40), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 50, 40), new Pixel(0, 50, 40), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        assertArrayEquals(target.frame, photo.frame);
    }

    @Test
    public void test2bOutOfOrder() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(9, 1, 1, -1, -1, 0, 1, 0);
        cam.insertPlane(2, 0, 1, -1, -1, 0, 0, 0);
        cam.insertPlane(0, 0, 0, 1, 2, 30, 50, 40);
        ImageFrame photo = cam.getPhoto(5);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{{new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(30, 50, 40), new Pixel(0, 0, 0)},
                        {new Pixel(30, 50, 40), new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        assertArrayEquals(target.frame, photo.frame);
    }

    @Test
    public void test2bNull() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(2, 1, 1, 2, 2, 0, 10, 0);
        cam.insertPlane(5, 0, 1, -1, -1, 20, 0, 0);
        cam.insertPlane(7, 0, 0, 1, 1, 0, 50, 0);

        ImageFrame photo = cam.getPhoto(5);

        assertEquals(null, photo);
    }

    @Test
    public void test2bTwoPics() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(2, 1, 1, 2, 2, 0, 10, 0);
        cam.insertPlane(5, 0, 1, -1, -1, 20, 0, 0);
        cam.insertPlane(7, 0, 0, 1, 1, 0, 50, 0);

        ImageFrame photo1 = cam.getPhoto(8);

        ImageFrame target1 = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 50, 0), new Pixel(0, 50, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 50, 0), new Pixel(0, 50, 0), new Pixel(20, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 10, 0), new Pixel(0, 10, 0)}});

        assertArrayEquals(target1.frame, photo1.frame);

        cam.insertPlane(4, 0, 0, 1, 1, 0, 42, 42);

        ImageFrame photo2 = cam.getPhoto(6);

        ImageFrame target2 = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 42, 42), new Pixel(20, 0, 0), new Pixel(0, 0, 0)},
                        {new Pixel(0, 42, 42), new Pixel(0, 42, 42), new Pixel(20, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 10, 0), new Pixel(0, 10, 0)}});

        assertArrayEquals(target2.frame, photo2.frame);
    }

    @Test
    public void test2bIndependentPixels() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0)},
                {new Pixel(0, 0, 0), new Pixel(0, 0, 0)}});

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(3, 0, 1, 1, 1, 0, 10, 0);

        ImageFrame photo1 = cam.getPhoto(8);

        ImageFrame target1 = new ImageFrame(
                new Pixel[][]{{new Pixel(0, 0, 0), new Pixel(0, 10, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 10, 0)}});

        cam.background.frame[0][0].r = 10;
        assertArrayEquals(target1.frame, photo1.frame);

        photo1.frame[1][1].r = 42;

        ImageFrame photo2 = cam.getPhoto(9);

        ImageFrame target2 = new ImageFrame(
                new Pixel[][]{{new Pixel(10, 0, 0), new Pixel(0, 10, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 10, 0)}});

        assertArrayEquals(target2.frame, photo2.frame);
    }
}