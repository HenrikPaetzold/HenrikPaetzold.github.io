import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Task1GradingTest {

	@Test
	public void testRightDistance1() {
		int[] input = new int[] {1,1,1,5,4};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {3,2,1,1,-1};
		assertArrayEquals(res, expected);
	}
	
	@Test
	public void testRightDistance2() {
		int[] input = new int[] {4,5,7,2,5,7,2,3};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {2,1,3,2,1,2,1,-1};
		assertArrayEquals(res, expected);
	}
	
	@Test
	public void testRightDistance3() {
		int[] input = new int[] {1};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {-1};
		assertArrayEquals(res, expected);
	}
	
	@Test
	public void testRightDistance4() {
		int[] input = new int[] {1, -10, 10, -10, 10};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {2,1,2,1,-1};
		assertArrayEquals(res, expected);
	}
	
	@Test
	public void testRightDistance5() {
		int[] input = new int[] {9,8,7,6,5,4,3,2,1};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {1,1,1,1,1,1,1,1,-1};
		assertArrayEquals(res, expected);
	}
	
	@Test
	public void testRightDistance6() {
		int[] input = new int[] {10,-100};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {1,-1};
		assertArrayEquals(res, expected);
	}
	
	@Test
	public void testInputChange() {
		// not allowed to change the input
		int[] input = new int[] {1,2,3,5,4,2,1};
		int[] input2 = new int[] {1,2,3,5,4,2,1};
		int[] res = Task1.rightDistance(input);
		assertArrayEquals(input, input2);
	}
}
