import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class Task2Test {

    @Test
    public void testFillRectangle() {
        ImageFrame frame = new ImageFrame(
                new Pixel[][]{
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)}
                });

        frame.fillRectangle(0, 0, 1, 1, 255, 255, 255);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{
                        {new Pixel(255, 255, 255), new Pixel(255, 255, 255), new Pixel(255, 0, 0)},
                        {new Pixel(255, 255, 255), new Pixel(255, 255, 255), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)}
                });

        assertArrayEquals(target.frame, frame.frame);
    }

    @Test
    public void testDrawDiagonal() {
        ImageFrame frame = new ImageFrame(
                new Pixel[][]{
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)}
                });

        frame.drawDiagonal(1, 0, 0, 0, 255);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(0, 0, 255), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(0, 0, 255), new Pixel(255, 0, 0)}
                });

        assertArrayEquals(target.frame, frame.frame);
    }

    @Test
    public void testCam() {
        ImageFrame frame = new ImageFrame(new Pixel[][]{
                {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)},
                {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(255, 0, 0)}
        });

        MultiplaneCamera cam = new MultiplaneCamera(frame);
        cam.insertPlane(5, 0, 0, 1, 2, 0, 0, 0);
        cam.insertPlane(7, 1, 1, -1, -1, 0, 255, 0);
        cam.insertPlane(10, 1, 1, -1, -1, 0, 0, 0);
        ImageFrame photo = cam.getPhoto(8);

        ImageFrame target = new ImageFrame(
                new Pixel[][]{
                        {new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(0, 0, 0), new Pixel(0, 255, 0), new Pixel(0, 0, 0), new Pixel(255, 0, 0)},
                        {new Pixel(255, 0, 0), new Pixel(255, 0, 0), new Pixel(0, 255, 0), new Pixel(255, 0, 0)}
                });

        assertArrayEquals(target.frame, photo.frame);
    }
}
