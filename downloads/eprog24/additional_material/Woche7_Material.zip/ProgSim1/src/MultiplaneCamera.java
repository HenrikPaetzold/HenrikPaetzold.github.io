/*
 * You MAY modify this file but do NOT remove, rename or change types of existing fields, methods, and constructors
 */

import java.util.Arrays;

public class MultiplaneCamera {

	ImageFrame background;
	ImageFrame[] frames = new ImageFrame[11];

	public MultiplaneCamera(ImageFrame background) {
		this.background = background;
	}

	public void insertPlane(int height, int x0, int y0, int x1, int y1, int r, int g, int b) {
		if (frames[height] != null)
			return;
		ImageFrame newPlane = new ImageFrame(new Pixel[background.frame.length][background.frame[0].length]);
		frames[height] = newPlane;
		if (x1 == -1 && y1 == -1) {
			newPlane.drawDiagonal(x0, y0, r, g, b);
		} else {
			newPlane.fillRectangle(x0, y0, x1, y1, r, g, b);
		}
	}

	public ImageFrame getPhoto(int height) {
		if (frames[height] != null)
			return null;
		Pixel[][] photo = new Pixel[background.frame.length][background.frame[0].length];
		for (int i = 0; i < photo.length; i++) {
			for (int j = 0; j < photo[i].length; j++) {
				Pixel framePixel = background.frame[i][j];
				if(framePixel != null) {
					photo[i][j] = new Pixel(framePixel.r, framePixel.g, framePixel.b);
				}
			}
		}
		
		for (int h = 0; h < height; h++) {
			ImageFrame curr = frames[h];
			if (curr != null) {
				Pixel[][] frame = curr.frame;
				for (int i = 0; i < frame.length; i++) {
					for (int j = 0; j < frame[i].length; j++) {
						Pixel framePixel = frame[i][j];
						if(framePixel != null) {
							photo[i][j] = new Pixel(framePixel.r, framePixel.g, framePixel.b);
						}
					}
				}
			}
		}
		return new ImageFrame(photo);
	}
}
