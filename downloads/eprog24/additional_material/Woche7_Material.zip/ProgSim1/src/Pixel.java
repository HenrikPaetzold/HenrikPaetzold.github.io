/*
 * Do NOT modify this file
 */

import java.util.Objects;

public class Pixel {
	int r;
	int g;
	int b;
	
	public Pixel() {}
	
	public Pixel(int r, int g, int b) {
		this.r = r;
		this.g = g;
		this.b = b;
	}

	@Override
	public int hashCode() {
		return Objects.hash(b, g, r);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pixel other = (Pixel) obj;
		return b == other.b && g == other.g && r == other.r;
	}

	@Override
	public String toString() {
		return "[" + r + ", " + g + ", " + b + "]";
	}
}
