public class Task1 {

    public static void main(String[] args) {
		int[] input = new int[] {1,1,1,5,4};
		int[] res = Task1.rightDistance(input);
    }
    
    public static int[] rightDistance(int[] input) {
    	int currMax = input[input.length-1];
    	int currMaxIndex = input.length-1;
    	int[] distance = new int[input.length];
    	distance[input.length-1] = -1;
    	for(int i = input.length-2; i >= 0; i--) {
    		distance[i] = Math.abs(i-currMaxIndex);
    		if(input[i] >= currMax) {
    			currMax = input[i];
    			currMaxIndex = i;
    		}
    	}
    	return distance;
    }
}
