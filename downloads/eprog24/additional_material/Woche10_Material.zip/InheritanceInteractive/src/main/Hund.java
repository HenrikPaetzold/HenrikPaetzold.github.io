package main;

public class Hund extends Tier {
//	int alter;
//	String name;
	
	public Hund(int alter, String name) {
		super(alter, name);
//		this.alter = alter;
//		this.name = name;
	}
	
	public String toString() {
		return alter + " " + name;
	}
	
	
}
