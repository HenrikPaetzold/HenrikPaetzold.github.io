package main;

public class Main {

	public static void main(String[] args) {
		// Initialisierung, Polymorphismus und Casting
//		Katze t1 = new Tiger(3, "Tiger1");
//		Löwe l1 = new Löwe(10, "löwe1");
		
		// Upcasts
//		Tier t2 = t1;
//		Katze l2 = new Löwe(11, "löwe2");
		
		// Downcasts
//		Katze k1 = (Katze) t2;
//		Tiger k2 = (Tiger) l1; 
		
		// Quercasts
//		Hund h1 = Hund(k1); 
//		Hund h2 = new Löwe();
		
		// Zugriff auf Attribute
		Hund h1 = new Hund(4, "hund1");
		/*
		System.out.println(h1.alter + " " + h1.name);
		
		h1.alter = 5;
		h1.name = "neuername"; 
		System.out.println(h1.alter + " " + h1.name);
		
		Tier h2 = h1; // impliziter upcast
		System.out.println(h2.alter + " " + h2.name); // Passiert nur, wenn variablen in Subklasse explizit angegeben werden 
		 */
		// Zugriff auf Methoden
		
		Tiger t1 = new Tiger(10, "t1");
		t1.macheGeräusch();
		h1.macheGeräusch();
//		System.out.println(t1.toString());
		
//		t1.alter = 11;
//		t1.name = "neuername";
//		System.out.println(t1.toString());
		
		// Super - Keyword
//		Husky h2 = new Husky(3,"husky1");
//		h2.macheGeräusch();
		
	}

}
