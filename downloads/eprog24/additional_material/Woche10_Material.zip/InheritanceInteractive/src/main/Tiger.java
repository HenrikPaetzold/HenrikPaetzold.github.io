package main;

public class Tiger extends Katze{
	int alter;
//	String name;
	public Tiger(int alter, String name) {
		super(alter, name);
		this.alter = alter;
		this.name = name;
	}

}
