package main;

public class Husky extends Hund {

	public Husky(int alter, String name) {
		super(alter, name);
	}
	
//	public void macheGeräusch() {
//		super.macheGeräusch();
//	}
	
}
