package main;

public class Löwe extends Katze {

	public Löwe(int alter, String name) {
		super(alter, name);
	}

}
