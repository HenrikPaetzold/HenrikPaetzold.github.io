package main;

public class Tier {
    // Öffentliche Attribute
    public int alter;
    public String name;

    // Private Attribute (Zugriff nur innerhalb der Klasse)
    private String farbe;
    private boolean istGefaehrlich;

    // Konstruktor
    public Tier(int alter, String name) {
        this.alter = alter;
        this.name = name;
        this.farbe = "Unbekannt"; // Standardwert
        this.istGefaehrlich = false; // Standardwert
    }

    // Getter und Setter für private Attribute
    public String getFarbe() {
        return farbe;
    }

    public void setFarbe(String farbe) {
        this.farbe = farbe;
    }

    public boolean isIstGefaehrlich() {
        return istGefaehrlich;
    }

    public void setIstGefaehrlich(boolean istGefaehrlich) {
        this.istGefaehrlich = istGefaehrlich;
    }
    
    public void macheGeräusch() {
    	System.out.println("Was für ein Tier bin ich?");
    }
    
    public String toString() {
    	return alter  + " " + name;
    }

    // Öffentliche Methode
    public void beschreibung() {
        System.out.println("Das Tier heißt " + name + ", ist " + alter + " Jahre alt und hat die Farbe " + farbe + ".");
        if (istGefaehrlich) {
            System.out.println("Dieses Tier ist gefährlich!");
        } else {
            System.out.println("Dieses Tier ist nicht gefährlich.");
        }
    }
}

