package main;

public class Katze extends Tier {
	int alter = 2;
	String name = "nochkeinname";
	public Katze (int alter, String name) {
		super(alter, name);
	}
	
	public void macheGeräusch() {
		System.out.println("Miau");
	}
}
