package main;

public class Student {
	// alter, name, legi, eingeschrieben
	
	// 2 konstruktoren ohne & mit this()
	
	// getter für alle
	
	// setter für alter
}
