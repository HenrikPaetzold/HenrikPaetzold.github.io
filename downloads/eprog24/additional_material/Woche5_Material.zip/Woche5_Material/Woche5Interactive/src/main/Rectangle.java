package main;
public class Rectangle {
    
}
