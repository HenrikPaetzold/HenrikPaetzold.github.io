interface Biom {

	public String getBiomType();
    /*
     *       "W" fuer Wasser
     *       "F" fuer Flachland
     */

	public int getFlora();
	
	public int getHeight();
}