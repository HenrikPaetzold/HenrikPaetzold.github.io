public class Node {

	/***
	*   Sie duerfen diese Klasse nicht verändern!
	***/
	private int value;
	
	public Node first;
	public Node second;
	
	public Node(int value) {
		this.value = value;
	}
	
	public Node(int value, Node first, Node second) {
		this.value = value;
		this.first = first;
		this.second = second;
	}
	
	public int getValue() {
		return value;
	}
	
	
	

}
