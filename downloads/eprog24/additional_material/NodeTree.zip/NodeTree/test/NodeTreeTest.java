import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class NodeTreeTest {
	public static Node buildExample() {
		// build tree from example
		Node seven = new Node(7);
		Node mtwo = new Node(-2, null, seven);
		Node one = new Node(1);
		Node four = new Node(4, mtwo, one);
		Node mthree = new Node(-3);
		Node two = new Node(2, mthree, four);
		return two;
	}
	
	@Test
	public void testCalculateSum() {
		// Aufgabe 2.1
		Node origin = buildExample();
		int res = NodeTree.calculateSum(origin);
		assertEquals(9, res);
	}

	@Test
	public void testHighestPath() {
		// Aufgabe 2.2
		Node origin = buildExample();
		int res = NodeTree.highestPath(origin);
		assertEquals(11, res);
	}
	
	
	
	
	public static Node[] buildExampleTriTree() {
		// only used for tasks 2.3 and 2.4
		Node seven = new Node(7);
		Node mtwo = new TriNode(-2, null, null, seven);
		Node one = new Node(1);
		Node four = new TriNode(4, mtwo, null, one);
		Node mthree = new Node(-3);
		Node two = new Node(2, mthree, four);
		return new Node[] {two, four, mtwo, seven};
	}
	
	@Test
	public void testCalculateTriSum() {
		Node origin = buildExampleTriTree()[0];
		int res = NodeTree.calculateTriSum(origin);
		assertEquals(9, res);
	}

	@Test
	public void testHighestTriPath() {
		Node[] correct = buildExampleTriTree();
		Node origin = correct[0];
		Node[] res = NodeTree.highestTriPath(origin);
		assertArrayEquals(correct, res);
	}
}
