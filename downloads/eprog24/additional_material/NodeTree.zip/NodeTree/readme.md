Dieses Projekt enthält eine Zusatzaufgabe, die ich in meiner Übungsstunde mit den Studierenden anschaue.
Die Aufgabe wurde von Marco Schöb für seine Übungsgruppe im HS23 erstellt.