package main;

public class Palindrome {
	public boolean isPalindrome(String word) {
		// TODO
	}
}
