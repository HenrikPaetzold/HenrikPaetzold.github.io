package main;

public class Pointers {
	public static void main(String[] args) {
		Coordinate coord1 = new Coordinate(2, 3);
		System.out.println(coord1);
		
		// vgl == hier
	}

	static class Coordinate {
		static int x;
		static int y;

		public Coordinate(int xcoord, int ycoord) {
			x = xcoord;
			y = ycoord;
		}
	}

}