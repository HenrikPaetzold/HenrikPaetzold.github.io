package main;

import java.util.Arrays;

public class WarmUp {
	public static void main(String[] args) {
		// Frage 1: Was passiert mit den beiden Werten?
		int a = 1;
		int b = 2;
		System.out.println("Vor dem Swap (primitive): a = " + a + ", b = " + b);
		swap(a, b);
		System.out.println("Nach dem Swap (primitive): a = " + a + ", b = " + b);
		
		// Frage 2: Was passiert hier?
		
		int[] KontoStandProTag = { 852, 352, 338 };
		System.out.println("Vor der Bereinigung des Kontostands: " + KontoStandProTag[KontoStandProTag.length - 1]);
		int bereinigterKontostand = accountBalanceWithoutRent(KontoStandProTag, 500, 2);
		System.out.println("Nach der Bereinigung des Kontostands: " + bereinigterKontostand);
		System.out.println(KontoStandProTag);
	}
	public static void swap(int a, int b) {

		int temp = b;
		b = a;
		a = temp;
	}
	public static int accountBalanceWithoutRent(int[] balance, int rent, int day) {
		int[] temp = balance;
		int prev = temp[0];
		boolean add = false;
		for (int i = 1; i < temp.length; i++) {
			int curr = temp[i];
			if (add || Math.abs(curr - prev) == rent) {
				add = true;
				temp[i] += rent;
			}
			prev = curr;
		}
		return temp[day - 1];
	}
	
}