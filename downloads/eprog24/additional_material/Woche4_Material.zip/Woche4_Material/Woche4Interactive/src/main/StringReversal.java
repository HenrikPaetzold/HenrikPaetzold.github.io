package main;

public class StringReversal {
	public String reverse(String word) {
		// TODO
	}
}
