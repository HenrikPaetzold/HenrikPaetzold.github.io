import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import main.Palindrome;

public class PalindromeTest {
    
    Palindrome palindrome = new Palindrome();

    // Test für einen leeren String
    @Test
    public void testEmptyString() {
        assertTrue(palindrome.isPalindrome(""));
    }

    // Test für ein einzelnes Zeichen
    @Test
    public void testSingleCharacter() {
        assertTrue(palindrome.isPalindrome("a"));
    }

    // Test für ein Wort mit zwei gleichen Zeichen
    @Test
    public void testTwoSameCharacters() {
        assertTrue(palindrome.isPalindrome("aa"));
    }

    // Test für ein Wort mit zwei verschiedenen Zeichen
    @Test
    public void testTwoDifferentCharacters() {
        assertFalse(palindrome.isPalindrome("ab"));
    }

    // Test für ein echtes Palindrom
    @Test
    public void testValidPalindrome() {
        assertTrue(palindrome.isPalindrome("racecar"));
    }

    // Test für ein Nicht-Palindrom
    @Test
    public void testInvalidPalindrome() {
        assertFalse(palindrome.isPalindrome("hello"));
    }

    // Test für ein Palindrom mit gemischter Groß-/Kleinschreibung
    @Test
    public void testCaseInsensitivePalindrome() {
        assertTrue(palindrome.isPalindrome("RaceCar"));
    }

    // Test für ein Palindrom mit Sonderzeichen und Leerzeichen
    @Test
    public void testPalindromeWithSpecialCharacters() {
        assertTrue(palindrome.isPalindrome("A man, a plan, a canal, Panama".replaceAll("[^a-zA-Z]", "").toLowerCase()));
    }
    @Test
    public void testPalindromeWithNumbers() {
        assertTrue(palindrome.isPalindrome("123abccba321"));
    }

    // Test für ein echtes Palindrom mit Zahlen
    @Test
    public void testValidPalindromeWithNumbers() {
        assertTrue(palindrome.isPalindrome("12321"));
    }

    // Test für einen Palindrom mit Leerzeichen
    @Test
    public void testPalindromeWithSpaces() {
        assertTrue(palindrome.isPalindrome("taco cat".replaceAll(" ", "")));
    }
}
