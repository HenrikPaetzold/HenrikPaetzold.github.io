import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import main.StringReversal;

public class StringReversalTest {

    StringReversal reverser = new StringReversal();

    // Test für einen leeren String
    @Test
    public void testEmptyString() {
        assertEquals("", reverser.reverse(""));
    }

    // Test für ein einzelnes Zeichen
    @Test
    public void testSingleCharacter() {
        assertEquals("a", reverser.reverse("a"));
    }

    // Test für einen einfachen String
    @Test
    public void testSimpleString() {
        assertEquals("olleh", reverser.reverse("hello"));
    }

    // Test für einen String mit zwei gleichen Zeichen
    @Test
    public void testTwoSameCharacters() {
        assertEquals("aa", reverser.reverse("aa"));
    }

    // Test für einen String mit zwei verschiedenen Zeichen
    @Test
    public void testTwoDifferentCharacters() {
        assertEquals("ba", reverser.reverse("ab"));
    }

    // Test für einen Palindrom-String
    @Test
    public void testPalindromeString() {
        assertEquals("racecar", reverser.reverse("racecar"));
    }

    // Test für einen String mit Sonderzeichen
    @Test
    public void testStringWithSpecialCharacters() {
        assertEquals("!dlroW ,olleH", reverser.reverse("Hello, World!"));
    }

    // Test für einen String mit Leerzeichen
    @Test
    public void testStringWithSpaces() {
        assertEquals("dlroW ,olleH", reverser.reverse("Hello, World"));
    }

    // Test für einen langen String
    @Test
    public void testLongString() {
        String longString = "abcdefghijklmnopqrstuvwxyz";
        String expectedReversed = "zyxwvutsrqponmlkjihgfedcba";
        assertEquals(expectedReversed, reverser.reverse(longString));
    }
}
