

public class PrefixConstruction {

	public static boolean isPrefixConstruction(String s, String t, int n) {
		// TODO: Implementieren Sie die Methode
		return false;
	}
}
