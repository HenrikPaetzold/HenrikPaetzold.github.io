// Unveränderte Lösung, die in der Stunde entstanden ist
public class Matrix {

	static boolean checkMatrix(int[][] m) {
		
	    /* 
	    Wir wollen folgende Bedingungen überprüfen:
	    1. Ist die Matrix quadratisch?
	    2. Gilt für alle Einträge x: x > 0 und x ≤ n^2, wobei n die Dimension der Matrix ist?
	    3. Sind die Werte einzigartig?
	    4. Sind die Zeilen- und Spaltensummen identisch?
	     */
	     
	    // Arrays zur Speicherung der Zeilen- und Spaltensummen
	    int[] col_sums = new int[m.length];
	    int[] row_sums = new int[m.length];
	    
	    // Durchläuft jede Zeile der Matrix
	    for (int i = 0; i < m.length; i++) {
	        // Überprüft, ob die Matrix quadratisch ist (Zeilen- und Spaltenanzahl müssen gleich sein)
	        if (m.length != m[i].length)
	            return false;
	        
	        // Durchläuft jede Spalte der aktuellen Zeile
	        for (int j = 0; j < m[i].length; j++) {
	            // Überprüft, ob die Werte im gültigen Bereich liegen (x > 0 und x ≤ n^2)
	            if (m[i][j] <= 0 || m[i][j] > Math.pow(m.length, 2))
	                return false;
	            
	            // Addiert den aktuellen Wert zur jeweiligen Spalten- und Zeilensumme
	            col_sums[j] += m[i][j];
	            row_sums[i] += m[i][j];
	            
	            // Überprüft, ob der aktuelle Wert einzigartig in der gesamten Matrix ist
	            for (int u = 0; u < m.length; u++) {
	                for (int v = 0; v < m[u].length; v++) {
	                    // Wenn der gleiche Wert an einer anderen Stelle vorkommt, ist er nicht einzigartig
	                	// Wir wollen einen Wert nicht mit sich selbst vergleichen, ansonsten würden wir immer false zurück geben. Daher (u != i und v != j)
	                    if (m[u][v] == m[i][j] && u != i && v != j)
	                        return false;
	                }
	            }
	        }
	    }
	    
	    // Speichert die erste Spalten- und Zeilensumme zum Vergleich
	    // Wir wissen inzwischen, dass es die Werte gibt durch die Bedingungen, die vorher überprüft wurden.
	    int col_temp = col_sums[0];
	    int row_temp = row_sums[0];
	    
	    for (int i = 0; i < m.length; i++) {
	    	// Überprüft, ob alle Spaltensummen gleich sind
	        if (col_sums[i] != col_temp)
	            return false;
	        // Überprüft, ob alle Zeilensummen gleich sind
	        if (row_sums[i] != row_temp)
	            return false;
	    }
	    
	    // Wenn alle Bedingungen erfüllt sind, gibt die Funktion true zurück
	    return true;
	}

}
