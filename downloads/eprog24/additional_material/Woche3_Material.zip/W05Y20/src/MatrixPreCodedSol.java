
public class MatrixSol {

	static boolean checkMatrix(int[][] m) {
		// check first conditions
		int[] row_sums = new int[m.length];
		int[] col_sums = new int[m.length];
		for (int i = 0; i < m.length; i++) {
			if (m[i].length != m.length)
				return false;
			for (int j = 0; j < m[i].length; j++) {
				if (m[i][j] > Math.pow(m.length, 2))
					return false;
				col_sums[j] += m[i][j];
				row_sums[i] += m[i][j];
				for (int u = i + 1; u < m.length; u++) {
					for (int v = j + 1; v < m[u].length; v++) {
						if (m[u][v] == m[i][j])
							return false;
					}
				}
			}
		}
		// check second conditions

		int row_temp = row_sums[0];
		int col_temp = row_sums[0];
		for (int i = 0; i < m.length; i++) {
			if (row_sums[i] != row_temp || col_sums[i] != col_temp)
				return false;
		}
		return true;
	}
}
