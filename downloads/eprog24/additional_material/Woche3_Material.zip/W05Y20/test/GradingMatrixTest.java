import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class GradingMatrixTest {

	int [] [] testBasic1True;
	int [] [] testBasic2True;
	int [] [] testCornerTrue;
	List<int [] []> testSumFalse;
	
	List<int [] []> testUniqueFalse;
	List<int [] []> testDomainFalse;
	List<int [] []> testDimensionsFalse;
	
	List<int [][]> allTrue;
	List<int [][]> allFalse;
	
	@Before
	public void before() {
		allTrue = new ArrayList<int [][]>();
		allFalse = new ArrayList<int [][]>();
		
		{
			int [][] in1 = {{11, 18, 25, 2, 9}, {10, 12, 19, 21, 3}, {4, 6, 13, 20, 22}, {23, 5, 7, 14, 16}, {17, 24, 1, 8, 15}};
			testBasic1True = in1;
			allTrue.add(in1);
		}
		
		{
			
			int [][] in2 = {{22, 31, 40, 49, 2, 11, 20}, 
					{21, 23, 32, 41, 43, 3, 12}, 
					{13, 15, 24, 33, 42, 44, 4}, 
					{5, 14, 16, 25, 34, 36, 45}, 
					{46, 6, 8, 17, 26, 35, 37}, 
					{38, 47, 7, 9, 18, 27, 29}, 
					{30, 39, 48, 1, 10, 19, 28}};
			testBasic2True = in2;
			allTrue.add(in2);
		}
		
		{
			int [][] in3 = { {1} };
			testCornerTrue = in3;
			allTrue.add(in3);
		}
		
		testSumFalse = new ArrayList<int[][]>();
		{
			int [][] in1 = { {1,2}, {3,4} };
			testSumFalse.add(in1);
			allFalse.add(in1);
			
			int [][] in2 = {{11, 18, 25, 2, 9}, {10, 12, 19, 21, 3}, {4, 6, 13, 20, 22}, {23, 7, 5, 14, 16}, {17, 24, 1, 8, 15}};
			testSumFalse.add(in2);
			allFalse.add(in2);
		}
		
		testUniqueFalse = new ArrayList<int[][]>();
		{
			int[][] in1 = { {1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1} };        
			testUniqueFalse.add(in1);
			allFalse.add(in1);
			
			int[][] in2 = { {4, 2, 1, 3}, {1, 4, 3, 2}, {3, 1, 2, 4}, {2, 3, 4, 1} };
			testUniqueFalse.add(in2);
			allFalse.add(in2);
			
			int[][] in3 = { {2,2}, {2,2} };
			testUniqueFalse.add(in3);
			allFalse.add(in3);
			
			int[][] in4 = { {1,2}, {2,1} };
			testUniqueFalse.add(in4);
			allFalse.add(in4);
		}
		
		testDomainFalse = new ArrayList<int[][]>();
		{
			int[][] in1 = { {3, 7, 11}, {10, 5, 6}, {8, 9, 4} };
			testDomainFalse.add(in1);
			allFalse.add(in1);
				
			int[][] in2 = {{13, 20, 27, 4, 11}, {12, 14, 21, 23, 5}, {6, 8, 15, 22, 24}, {25, 7, 9, 16, 18}, {19, 26, 3, 10, 17}};
			testDomainFalse.add(in2);
			allFalse.add(in2);
			
			int [][] in3 = { {2} };
			testDomainFalse.add(in3);
			allFalse.add(in3);
		}
		
		testDimensionsFalse = new ArrayList<int[][]>();
		{
			int[][] in1 = { {6,7,2}, {1,5,9,10}, {8,3,4}};
			testDimensionsFalse.add(in1);
			allFalse.add(in1);
			
			int[][] in2 = { {8,3,4}, {1,5,9}, {6,7,2}, {8,3,4}, {1,5,9}, {6,7,2} };
			testDimensionsFalse.add(in2);
			allFalse.add(in2);
			
			int[][] in3 = { {1,1} };
			testDimensionsFalse.add(in3);
			allFalse.add(in3);
		}
		
		{
			int [][] control = { {6, 7, 2}, {1, 5, 9}, {8, 3, 4} };
			allTrue.add(control);
		}
	}
	
	public boolean atLeastOneTrue() {
		for(int [][] square : allTrue) {
			try {
				boolean res = Matrix.checkMatrix(square);
				if(res) {
					return true; 
				}
			} catch(Throwable e) {
				//ignore execution
			}
		}
		return false;
	}
	
	public boolean atLeastOneFalse() {
		for(int [][] square : allFalse) {
			try {
				boolean res = Matrix.checkMatrix(square);
				if(!res) {
					return true;
				}
			} catch(Throwable e) {
				//ignore execution
			}
		}
		return false;
	}
	
	
	@Test
	public void testBasic1() {
		assertTrue(Matrix.checkMatrix(testBasic1True));
		assertTrue(atLeastOneFalse());
	}
	
	@Test
	public void testBasic2() {
		assertTrue(Matrix.checkMatrix(testBasic2True));
		assertTrue(atLeastOneFalse());
	}
	
	@Test
	public void testCorner() {
		assertTrue(Matrix.checkMatrix(testCornerTrue));
		assertTrue(atLeastOneFalse());
	}
	
	@Test
	public void testSumFalse() {
		for(int [][] square : testSumFalse) {
			assertFalse(Matrix.checkMatrix(square));
		}
		
		assertTrue(atLeastOneTrue());
	}

	
	@Test
	public void testUnique() {
		for(int [][] square : testUniqueFalse) {
			assertFalse(Matrix.checkMatrix(square));
		}
		
		assertTrue(atLeastOneTrue());
	}
	
	
	@Test
	public void testDomain() {		
		for(int [][] square : testDomainFalse) {
			assertFalse(Matrix.checkMatrix(square));
		}
		
		assertTrue(atLeastOneTrue());		
	}
	
	@Test
	public void testDimensions() {
		for(int [][] square : testDimensionsFalse) {
			assertFalse(Matrix.checkMatrix(square));
		}
		
		assertTrue(atLeastOneTrue());
	}
	
	@Test
	public void testLarge() {
		for(int i = 23; i < 37; i += 1) {
			int[][] square = generateMagicSquare(i);
			if (i % 13 == 0) {
				int z = square[7][11];
				square[7][11] = square[5][3];
				square[5][3] = z;
				assertFalse(Matrix.checkMatrix(square));
			} else {
				assertTrue(Matrix.checkMatrix(square));
			}
		}
	}
	
	static int[][] generateMagicSquare(int idx) {
		int d = 2*idx + 1;
		int[][] res = new int[d][d];
		
		int x = d-1;
        int y = d/2;
        res[x][y] = 1;

        int maxNum = d*d;
        for (int i = 2; i <= maxNum; i += 1) {
        	int a = (x + 1) % d, b = (y + 1) % d;
            if (res[a][b] == 0) {
                x = a;
                y = b;
            } else {
                x = (x - 1 + d) % d;
            }
            res[x][y] = i;
        }
        
        return res;
	}


}