import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class Task2GradingTest2 {

	@Test
	public void test2aFillRectangle() {
		ImageFrame frame = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 0, 0), new Pixel(0, 0, 0) },
						{ new Pixel(0, 0, 0), new Pixel(0, 0, 0) },
						{ new Pixel(0, 0, 0), new Pixel(0, 0, 0) } });

		frame.fillRectangle(1, 0, 2, 1, 255, 255, 255);
		frame.fillRectangle(0, 1, 1, 1, 0, 100, 0);

		ImageFrame target = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 0, 0), new Pixel(0, 100, 0)},
						{ new Pixel(255, 255, 255), new Pixel(0, 100, 0)},
						{ new Pixel(255, 255, 255), new Pixel(255, 255, 255)} });

		assertArrayEquals(target.frame, frame.frame);
	}
	
	@Test
	public void test2aDrawDiagonal() {
		ImageFrame frame = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0) },
						{ new Pixel(0, 0, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0) },
						{ new Pixel(0, 255, 0), new Pixel(0, 0, 0), new Pixel(0, 0, 0 ) } });

		frame.drawDiagonal(0, 1, 0, 0, 255);
		frame.drawDiagonal(1, 0, 0, 0, 100);

		ImageFrame target = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 0, 0), new Pixel(0, 0, 255), new Pixel(0, 0, 0) },
						{ new Pixel(0, 0, 100), new Pixel(0, 0, 0), new Pixel(0, 0, 255) },
						{ new Pixel(0, 255, 0), new Pixel(0, 0, 100), new Pixel(0, 0, 0) } });

		assertArrayEquals(target.frame, frame.frame);
	}

	/*
	 * The following test verifies that each pixel was created as an independent object.
	 * If yout placed the same Pixel into multiple locations, this test might catch that.
	 */
	@Test
	public void test2aIndependentPixels() {
		ImageFrame frame = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 0, 0), new Pixel(0, 0, 0) },
						{ new Pixel(0, 0, 0), new Pixel(0, 0, 0) } });
		
		// All pixels get colored red
		frame.fillRectangle(0, 0, 1, 1, 100, 0, 0);
		
		// We modify a single pixel
		frame.frame[0][0].r = 0;
		
		ImageFrame target = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 0, 0), new Pixel(100, 0, 0) },
						{ new Pixel(100, 0, 0), new Pixel(100, 0, 0)} });

		assertArrayEquals(target.frame, frame.frame);
	}
	
	@Test
	public void test2bSimple() {
		ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)}});
		
		MultiplaneCamera cam = new MultiplaneCamera(frame);
		cam.insertPlane(0, 0, 0, 1, 2, 30, 50, 40);
		cam.insertPlane(2, 0, 1, -1, -1, 0, 0, 0);
		cam.insertPlane(9, 1, 1, -1, -1, 0, 1, 0);
		ImageFrame photo = cam.getPhoto(5);

		ImageFrame target = new ImageFrame(
				new Pixel[][] { { new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(30, 50, 40), new Pixel(0,0,0) },
						{ new Pixel(30, 50, 40), new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(0,0,0) } });

		assertArrayEquals(target.frame, photo.frame);
	}
	
	/*
	 * This test checks that a second insert on the same height gets ignored
	 */
	@Test
	public void test2bDoubleInsert() {
		ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)}});
		
		MultiplaneCamera cam = new MultiplaneCamera(frame);
		// insertion into height 5
		cam.insertPlane(5, 0, 0, 1, 1, 0, 50, 40);
		cam.insertPlane(9, 1, 1, -1, -1, 0, 1, 0);
		
		// insertion into height 5: should get ignored
		cam.insertPlane(5, 0, 1, -1, -1, 10, 10, 0);
		ImageFrame photo = cam.getPhoto(7);

		ImageFrame target = new ImageFrame(
				new Pixel[][] { { new Pixel(0, 50, 40), new Pixel(0, 50, 40), new Pixel(0, 0, 0), new Pixel(0,0,0) },
						{ new Pixel(0, 50, 40), new Pixel(0, 50, 40), new Pixel(0, 0, 0), new Pixel(0,0,0) } });

		assertArrayEquals(target.frame, photo.frame);
	}
	
	/*
	 * The insertion order of the frames is different here. The insertion order should not matter for the result.
	 * But some implementations may have assumed some order.
	 */
	@Test
	public void test2bOutOfOrder() {
		ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)}});
		
		MultiplaneCamera cam = new MultiplaneCamera(frame);
		cam.insertPlane(9, 1, 1, -1, -1, 0, 1, 0);
		cam.insertPlane(2, 0, 1, -1, -1, 0, 0, 0);
		cam.insertPlane(0, 0, 0, 1, 2, 30, 50, 40);
		ImageFrame photo = cam.getPhoto(5);

		ImageFrame target = new ImageFrame(
				new Pixel[][] { { new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(30, 50, 40), new Pixel(0,0,0) },
						{ new Pixel(30, 50, 40), new Pixel(30, 50, 40), new Pixel(0, 0, 0), new Pixel(0,0,0) } });

		assertArrayEquals(target.frame, photo.frame);
	}

	/*
	 * Verify that the method returns null if the cam is on an occupied height
	 */
	@Test
	public void test2bNull() {
		ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)}});
		
		MultiplaneCamera cam = new MultiplaneCamera(frame);
		cam.insertPlane(2, 1, 1, 2, 2, 0, 10, 0);
		
		// insert glass pane on height 5
		cam.insertPlane(5, 0, 1, -1, -1, 20, 0, 0);
		cam.insertPlane(7, 0, 0, 1, 1, 0, 50, 0);
		
		// cannot take photo on height 5
		ImageFrame photo = cam.getPhoto(5);

		assertEquals(null, photo);
	}
	
	/*
	 * This method creates two photos from different heights.
	 * Nothing special going on but depending on the implementation, this could fail.
	 */
	@Test
	public void test2bTwoPics() {
		ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0), new Pixel(0,0,0)}});
		
		MultiplaneCamera cam = new MultiplaneCamera(frame);
		cam.insertPlane(2, 1, 1, 2, 2, 0, 10, 0);
		cam.insertPlane(5, 0, 1, -1, -1, 20, 0, 0);
		cam.insertPlane(7, 0, 0, 1, 1, 0, 50, 0);
		
		//first picture on
		ImageFrame photo1 = cam.getPhoto(8);

		ImageFrame target1 = new ImageFrame(
				new Pixel[][] { { new Pixel(0,50,0), new Pixel(0,50,0), new Pixel(0,0,0) },
						{ new Pixel(0,50,0), new Pixel(0,50,0), new Pixel(20,0,0) },
						{new Pixel(0,0,0), new Pixel(0,10,0), new Pixel(0,10,0)}});
		
		assertArrayEquals(target1.frame, photo1.frame);
		
		// additional insertion that should only affect the second picture
		cam.insertPlane(4, 0, 0, 1, 1, 0, 42, 42);
		
		// second picture on a different height
		ImageFrame photo2 = cam.getPhoto(6);

		ImageFrame target2 = new ImageFrame(
				new Pixel[][] { { new Pixel(0,42,42), new Pixel(20,0,0), new Pixel(0,0,0) },
						{ new Pixel(0,42,42), new Pixel(0,42,42), new Pixel(20,0,0) },
						{new Pixel(0,0,0), new Pixel(0,10,0), new Pixel(0,10,0)}});
		
		assertArrayEquals(target2.frame, photo2.frame);
	}
	
	/*
	 * This test verifies that pixels are not placed into multiple ImageFrames that are exposed to the testing suite.
	 * Specifically: 
	 * - taking a photo and then modifying the background should NOT modify the photo
	 * - a modification of a photo should NOT affect future photos
	 */
	@Test
	public void test2bIndependentPixels() {
		ImageFrame frame = new ImageFrame(new Pixel[][] 
				{{new Pixel(0,0,0), new Pixel(0,0,0)},
				{new Pixel(0,0,0), new Pixel(0,0,0)}});
		
		MultiplaneCamera cam = new MultiplaneCamera(frame);
		cam.insertPlane(3, 0, 1, 1, 1, 0, 10, 0);
		
		// Create photo
		ImageFrame photo1 = cam.getPhoto(8);
		
		ImageFrame target1 = new ImageFrame(
				new Pixel[][] { { new Pixel(0,0,0), new Pixel(0,10,0) },
						{ new Pixel(0,0,0), new Pixel(0,10,0)}});
		
		// Modify background - photo shouldn't be affected
		cam.background.frame[0][0].r = 10;
		assertArrayEquals(target1.frame, photo1.frame);
		
		// Modify first photo
		photo1.frame[1][1].r = 42;
		
		// Second photo should get affected by background modification but not by photo modification
		ImageFrame photo2 = cam.getPhoto(9);

		ImageFrame target2= new ImageFrame(
				new Pixel[][] { { new Pixel(10,0,0), new Pixel(0,10,0) },
						{ new Pixel(0,0,0), new Pixel(0,10,0)}});

		assertArrayEquals(target2.frame, photo2.frame);
	}	
}
