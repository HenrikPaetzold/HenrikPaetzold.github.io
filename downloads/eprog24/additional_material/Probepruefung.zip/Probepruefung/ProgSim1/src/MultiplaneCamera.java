/*
 * You MAY modify this file but do NOT remove, rename or change types of existing fields, methods, and constructors
 */
public class MultiplaneCamera {

	ImageFrame background;

	public MultiplaneCamera(ImageFrame background) {
		this.background = background;
	}

	public void insertPlane(int height, int x0, int y0, int x1, int y1, int r, int g, int b) {
		// TODO Task 2b
		
	}

	public ImageFrame getPhoto(int height) {
		// TODO Task 2b
		
		return new ImageFrame(new Pixel[0][0]);
	}
}
