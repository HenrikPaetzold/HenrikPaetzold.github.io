public class Task1 {

    public static void main(String[] args) {
		int[] input = new int[] {1,1,1,5,4};
		int[] res = Task1.rightDistance(input);
    }
    
    public static int[] rightDistance(int[] input) {
    	// TODO Aufgabe 1
    	return null;
    }
}
