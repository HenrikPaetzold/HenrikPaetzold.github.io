import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Task1Test {

	@Test
	public void testRightDistance1() {
		int[] input = new int[] {1,1,1,5,4};
		int[] res = Task1.rightDistance(input);
		int[] expected = new int[] {3,2,1,1,-1};
		assertArrayEquals(res, expected);
	}
}
